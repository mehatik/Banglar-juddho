# Banglar Juddho — UI update

This update keeps the existing React + Vite + Three.js project and gameplay code intact.

## UI changes
- Enlarged the landscape movement joystick and expanded its touch target.
- Enlarged the circular combat deck, especially Punch, and increased the other action controls.
- Reduced and raised the player HUD and HP bars.
- Reduced the center round/timer card.
- Reduced the top-right utility buttons.
- Added dedicated short-landscape phone sizing and safe-area spacing.

## Run locally
Requires Node.js 22.13+ (or 24+) as specified in package.json.

```bash
npm install
npm run dev
```

Production build:
```bash
npm run build
```

The changes are CSS-only; existing combat, CPU, Three.js rendering, touch handlers, and keyboard shortcuts were not intentionally changed.
