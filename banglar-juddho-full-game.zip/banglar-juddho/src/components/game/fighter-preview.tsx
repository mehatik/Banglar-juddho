import { useEffect, useRef } from 'react'
import type p5 from 'p5'
import { MODEL_HEIGHT, drawCharacter, type Anim } from './characters'

/**
 * Small animated p5.js canvas showing one fighter model, used on the
 * character-select cards and the match newspaper.
 */
export function FighterPreview({
  id,
  anim = 'idle',
  label,
  className = 'portrait-svg',
  bust = false,
}: {
  id: number
  anim?: Anim
  label: string
  className?: string
  /** Frame the head and torso instead of the full body. */
  bust?: boolean
}) {
  const host = useRef<HTMLDivElement>(null)
  const live = useRef({ id, anim, bust })
  useEffect(() => {
    live.current = { id, anim, bust }
  }, [id, anim, bust])

  useEffect(() => {
    const el = host.current!
    let instance: p5 | null = null
    let disposed = false
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    import('p5')
      .then(({ default: P5 }) => {
        if (disposed) return
        instance = new P5((s: p5) => {
          let started = 0
          let visible = true
          const io = new IntersectionObserver(([entry]) => {
            visible = entry.isIntersecting
          })
          s.setup = () => {
            const c = s.createCanvas(el.clientWidth || 160, el.clientHeight || 160)
            c.elt.setAttribute('aria-hidden', 'true')
            s.pixelDensity(Math.min(window.devicePixelRatio || 1, 2))
            s.frameRate(30)
            started = s.millis()
            io.observe(el)
          }
          s.draw = () => {
            if (!visible) return
            if (el.clientWidth !== s.width || el.clientHeight !== s.height)
              s.resizeCanvas(el.clientWidth || 1, el.clientHeight || 1)
            const { id: who, anim: a, bust: b } = live.current
            const t = (s.millis() - started) / 1000
            s.clear()
            const h = s.height
            const k = (b ? h * 1.75 : h * 0.9) / MODEL_HEIGHT[who]
            s.push()
            s.translate(s.width / 2 - (b ? 0 : 6 * k), b ? h * 1.68 : h * 0.97)
            s.scale(k, k)
            drawCharacter(s, who, { anim: a, t, clock: t }, { reduced })
            s.pop()
          }
          const remove = s.remove.bind(s)
          s.remove = () => {
            io.disconnect()
            remove()
          }
        }, el)
      })
      .catch(() => {})
    return () => {
      disposed = true
      instance?.remove()
    }
  }, [])

  return <div ref={host} className={`fighter-preview ${className}`} role="img" aria-label={label} />
}
