import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  FlipHorizontal2,
  RotateCcw,
  Check,
  X,
  Eye,
  EyeOff,
  LayoutGrid,
  ChevronUp,
  ChevronDown,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Settings model + persistence                                       */
/* ------------------------------------------------------------------ */

export type HudKey = "stick" | "punch" | "kick" | "guard" | "special" | "burst";
export const HUD_KEYS: HudKey[] = [
  "stick",
  "punch",
  "kick",
  "guard",
  "special",
  "burst",
];
export const HUD_LABELS: Record<HudKey, string> = {
  stick: "Joystick",
  punch: "Punch",
  kick: "Kick",
  guard: "Guard",
  special: "Super",
  burst: "Burst",
};
/** Base diameter of each control, in HUD units (--ko-u). */
const HUD_BASE: Record<HudKey, number> = {
  stick: 2.5,
  punch: 1.65,
  kick: 1.2,
  guard: 1.12,
  special: 1.26,
  burst: 0.92,
};
/** Controls that may be hidden from the HUD. Movement and punch always stay. */
const HIDEABLE: HudKey[] = ["kick", "guard", "special", "burst"];

export type HudItem = { x: number; y: number; s: number; hidden?: boolean };
export type HudLayout = Record<HudKey, HudItem>;
export type HudSettings = {
  layout: HudLayout;
  opacity: number;
  scale: number;
  labels: boolean;
  haptics: boolean;
  combo: boolean;
  hpNumbers: boolean;
};

const CLASSIC: HudLayout = {
  stick: { x: 13, y: 74, s: 1 },
  punch: { x: 88, y: 76, s: 1 },
  kick: { x: 75.5, y: 85, s: 1 },
  guard: { x: 77, y: 63, s: 1 },
  special: { x: 88.5, y: 52, s: 1 },
  burst: { x: 67, y: 72, s: 1 },
};
const COMPACT: HudLayout = {
  stick: { x: 11, y: 78, s: 0.86 },
  punch: { x: 90, y: 80, s: 0.9 },
  kick: { x: 80, y: 88, s: 0.88 },
  guard: { x: 81, y: 69, s: 0.88 },
  special: { x: 90.5, y: 61, s: 0.9 },
  burst: { x: 73, y: 79, s: 0.88 },
};
const mirror = (l: HudLayout): HudLayout =>
  Object.fromEntries(
    HUD_KEYS.map((k) => [k, { ...l[k], x: 100 - l[k].x }]),
  ) as HudLayout;

export const HUD_PRESETS: { id: string; name: string; layout: HudLayout }[] = [
  { id: "classic", name: "Classic", layout: CLASSIC },
  { id: "left", name: "Left-handed", layout: mirror(CLASSIC) },
  { id: "compact", name: "Compact", layout: COMPACT },
];

export const DEFAULT_HUD: HudSettings = {
  layout: CLASSIC,
  opacity: 0.92,
  scale: 1,
  labels: true,
  haptics: true,
  combo: true,
  hpNumbers: true,
};

const STORAGE_KEY = "banglar-juddho.hud.v1";
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const num = (v: unknown, fallback: number, a: number, b: number) =>
  typeof v === "number" && Number.isFinite(v) ? clamp(v, a, b) : fallback;

/** Reads saved HUD settings, repairing anything missing or out of range. */
export function loadHud(): HudSettings {
  try {
    const raw =
      typeof localStorage !== "undefined"
        ? localStorage.getItem(STORAGE_KEY)
        : null;
    if (!raw) return DEFAULT_HUD;
    const saved = JSON.parse(raw) as Partial<HudSettings>;
    const layout = Object.fromEntries(
      HUD_KEYS.map((k) => {
        const d = CLASSIC[k];
        const it = (saved.layout?.[k] ?? {}) as Partial<HudItem>;
        return [
          k,
          {
            x: num(it.x, d.x, 2, 98),
            y: num(it.y, d.y, 2, 98),
            s: num(it.s, 1, 0.6, 1.6),
            hidden: HIDEABLE.includes(k) && it.hidden === true,
          },
        ];
      }),
    ) as HudLayout;
    return {
      layout,
      opacity: num(saved.opacity, DEFAULT_HUD.opacity, 0.25, 1),
      scale: num(saved.scale, 1, 0.7, 1.4),
      labels: saved.labels ?? DEFAULT_HUD.labels,
      haptics: saved.haptics ?? DEFAULT_HUD.haptics,
      combo: saved.combo ?? DEFAULT_HUD.combo,
      hpNumbers: saved.hpNumbers ?? DEFAULT_HUD.hpNumbers,
    };
  } catch {
    return DEFAULT_HUD;
  }
}

export function useHudSettings() {
  const [hud, setHud] = useState<HudSettings>(loadHud);
  const update = useCallback((next: HudSettings) => {
    setHud(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Private browsing may block storage; settings still apply for this session.
    }
  }, []);
  return [hud, update] as const;
}

/* ------------------------------------------------------------------ */
/*  Layer: positions each control from the saved layout                */
/* ------------------------------------------------------------------ */

export function HudLayer({
  settings,
  items,
  editing = false,
  selected,
  onSelect,
  onMove,
}: {
  settings: HudSettings;
  items: Record<HudKey, ReactNode>;
  editing?: boolean;
  selected?: HudKey | null;
  onSelect?: (key: HudKey) => void;
  onMove?: (key: HudKey, x: number, y: number) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef<{ key: HudKey; dx: number; dy: number } | null>(null);
  const style = {
    "--hud-opacity": settings.opacity,
    "--hud-scale": settings.scale,
  } as CSSProperties;

  const pointer = (
    e: React.PointerEvent,
    key: HudKey,
    phase: "down" | "move" | "up",
  ) => {
    if (!editing) return;
    const rect = ref.current!.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * 100;
    const py = ((e.clientY - rect.top) / rect.height) * 100;
    if (phase === "down") {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      const it = settings.layout[key];
      drag.current = { key, dx: it.x - px, dy: it.y - py };
      onSelect?.(key);
    } else if (phase === "move" && drag.current?.key === key) {
      onMove?.(
        key,
        clamp(px + drag.current.dx, 3, 97),
        clamp(py + drag.current.dy, 4, 96),
      );
    } else if (phase === "up") {
      drag.current = null;
    }
  };

  return (
    <div
      ref={ref}
      className={`ko-hud${editing ? " editing" : ""}${settings.labels ? "" : " no-labels"}`}
      style={style}
    >
      {HUD_KEYS.map((key) => {
        const it = settings.layout[key];
        if (it.hidden && !editing) return null;
        return (
          <div
            key={key}
            className={`ko-slot slot-${key}${selected === key ? " selected" : ""}${it.hidden ? " is-hidden" : ""}`}
            style={
              {
                left: `${it.x}%`,
                top: `${it.y}%`,
                "--slot": HUD_BASE[key] * it.s,
              } as CSSProperties
            }
            onPointerDown={editing ? (e) => pointer(e, key, "down") : undefined}
            onPointerMove={editing ? (e) => pointer(e, key, "move") : undefined}
            onPointerUp={editing ? (e) => pointer(e, key, "up") : undefined}
            onPointerCancel={editing ? (e) => pointer(e, key, "up") : undefined}
            role={editing ? "button" : undefined}
            tabIndex={editing ? 0 : undefined}
            aria-label={editing ? `Move ${HUD_LABELS[key]} control` : undefined}
            onKeyDown={
              editing
                ? (e) => {
                    const step = e.shiftKey ? 5 : 1;
                    const d = {
                      ArrowLeft: [-step, 0],
                      ArrowRight: [step, 0],
                      ArrowUp: [0, -step],
                      ArrowDown: [0, step],
                    }[e.key];
                    if (!d) return;
                    e.preventDefault();
                    onSelect?.(key);
                    onMove?.(
                      key,
                      clamp(it.x + d[0], 3, 97),
                      clamp(it.y + d[1], 4, 96),
                    );
                  }
                : undefined
            }
          >
            {items[key]}
            {editing && (
              <span className="slot-tag">
                {HUD_LABELS[key]}
                {it.hidden ? " · hidden" : ""}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  K.O.-style round combat buttons                                    */
/* ------------------------------------------------------------------ */

export type CombatIconKind = "punch" | "kick" | "super" | "burst" | "guard";

export function CombatIcon({ kind }: { kind: CombatIconKind }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" focusable="false">
      {kind === "punch" && (
        <>
          <path
            d="m21 35-7-8c-4-5 2-10 6-6l5 5-7-12c-3-5 4-9 7-4l7 12-4-13c-2-6 6-8 8-2l4 14-1-11c0-6 8-6 8 0l1 19 5-6c4-4 10 1 7 5L48 47l-1 9H27l-1-9Z"
            fill="currentColor"
            transform="translate(-3 0)"
          />
          <path
            d="m13 43 8 8M8 48l10 9M10 35l6 6"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </>
      )}
      {kind === "kick" && (
        <>
          <circle cx="36" cy="12" r="6" fill="currentColor" />
          <path
            d="m32 23 10 6 15-6M33 25l-8 12-17-6M28 36l14 6 9 14M30 24l-11-5-9 3"
            stroke="currentColor"
            strokeWidth="7"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      )}
      {kind === "super" && (
        <>
          <path
            d="M32 5C15 3 3 20 8 37c2-13 10-18 19-17C15 26 16 42 29 47 20 38 23 29 32 28c-4 5-2 11 4 12 11 2 18-14 10-25 13 7 15 25 3 36 18-7 21-33 5-44 4 9 3 17-1 21C53 12 43 5 32 5Z"
            fill="currentColor"
          />
          <path
            d="M12 46c8 13 27 16 39 5-13 4-23 1-28-7"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </>
      )}
      {kind === "burst" && (
        <>
          <path d="M10 22h40v13H31l-4 17H15l5-20H10Z" fill="currentColor" />
          <path
            d="M33 36v6h-6M54 18l5-4M55 27h6M52 36l6 5"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </>
      )}
      {kind === "guard" && (
        <path
          d="M32 6 10 14v15c0 14 9 24 22 29 13-5 22-15 22-29V14L32 6Zm0 8 14 5v10c0 9-5 16-14 20V14Z"
          fill="currentColor"
        />
      )}
    </svg>
  );
}

export function KoButton({
  kind,
  label,
  hint,
  tone,
  ring = 1,
  ready = false,
  disabled = false,
  ariaLabel,
  title,
  onPress,
  onRelease,
}: {
  kind: CombatIconKind;
  label: string;
  hint?: string;
  tone: "red" | "amber" | "teal" | "gold" | "ember";
  /** 0..1 fill of the outer ring (cooldown or super charge). */
  ring?: number;
  ready?: boolean;
  disabled?: boolean;
  ariaLabel: string;
  title?: string;
  onPress?: () => void;
  onRelease?: () => void;
}) {
  return (
    <button
      type="button"
      className={`ko-btn tone-${tone}${ready ? " is-ready" : ""}`}
      style={{ "--ring": clamp(ring, 0, 1) } as CSSProperties}
      disabled={disabled}
      aria-label={ariaLabel}
      title={title}
      onPointerDown={(e) => {
        if (disabled) return;
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        e.currentTarget.classList.add("is-pressed");
        onPress?.();
      }}
      onPointerUp={(e) => {
        e.currentTarget.classList.remove("is-pressed");
        onRelease?.();
      }}
      onPointerCancel={(e) => {
        e.currentTarget.classList.remove("is-pressed");
        onRelease?.();
      }}
      onLostPointerCapture={(e) => {
        e.currentTarget.classList.remove("is-pressed");
        onRelease?.();
      }}
      onKeyDown={(e) => {
        if ((e.key === "Enter" || e.key === " ") && !e.repeat) {
          e.preventDefault();
          e.stopPropagation();
          onPress?.();
        }
      }}
      onKeyUp={(e) => {
        if (e.key === "Enter" || e.key === " ") onRelease?.();
      }}
    >
      <span className="ko-ring" aria-hidden="true" />
      <span className="ko-face" aria-hidden="true">
        <CombatIcon kind={kind} />
        <span className="ko-label">
          {label}
          {hint && <kbd>{hint}</kbd>}
        </span>
      </span>
    </button>
  );
}

/** Static stand-ins rendered inside the layout editor. */
export const PREVIEW_ITEMS: Record<HudKey, ReactNode> = {
  stick: (
    <div className="joystick ko-stick" aria-hidden="true">
      <span className="joystick-directions">
        <i />
        <i />
        <i />
        <i />
      </span>
      <span className="joystick-knob" />
    </div>
  ),
  punch: (
    <KoButton
      kind="punch"
      label="PUNCH"
      hint="J"
      tone="red"
      ariaLabel="Punch preview"
    />
  ),
  kick: (
    <KoButton
      kind="kick"
      label="KICK"
      hint="K"
      tone="amber"
      ariaLabel="Kick preview"
    />
  ),
  guard: (
    <KoButton
      kind="guard"
      label="GUARD"
      hint="S"
      tone="teal"
      ariaLabel="Guard preview"
    />
  ),
  special: (
    <KoButton
      kind="super"
      label="SUPER"
      hint="L"
      tone="gold"
      ring={0.7}
      ariaLabel="Super preview"
    />
  ),
  burst: (
    <KoButton
      kind="burst"
      label="BURST"
      hint="I"
      tone="ember"
      ariaLabel="Burst preview"
    />
  ),
};

/* ------------------------------------------------------------------ */
/*  Layout editor                                                      */
/* ------------------------------------------------------------------ */

export function HudEditor({
  initial,
  onSave,
  onCancel,
}: {
  initial: HudSettings;
  onSave: (next: HudSettings) => void;
  onCancel: () => void;
}) {
  const [draft, setDraft] = useState<HudSettings>(initial);
  const [selected, setSelected] = useState<HudKey | null>("punch");
  const [collapsed, setCollapsed] = useState(false);
  const it = selected ? draft.layout[selected] : null;
  const setItem = (key: HudKey, patch: Partial<HudItem>) =>
    setDraft((d) => ({
      ...d,
      layout: { ...d.layout, [key]: { ...d.layout[key], ...patch } },
    }));

  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onCancel]);

  return (
    <div
      className="hud-editor"
      role="dialog"
      aria-modal="true"
      aria-label="Customize HUD layout"
    >
      <div className="hud-editor-grid" aria-hidden="true" />
      <HudLayer
        settings={draft}
        items={PREVIEW_ITEMS}
        editing
        selected={selected}
        onSelect={setSelected}
        onMove={(key, x, y) => setItem(key, { x, y })}
      />
      <section
        className={`hud-editor-panel${collapsed ? " is-collapsed" : ""}`}
      >
        <header>
          <span className="edition">CUSTOM HUD</span>
          <strong>{selected ? HUD_LABELS[selected] : "Drag a control"}</strong>
          <small>
            Drag controls to move them. Arrow keys nudge the selected control.
          </small>
          <button
            type="button"
            className="panel-toggle"
            aria-expanded={!collapsed}
            aria-label={
              collapsed ? "Show editor options" : "Hide editor options"
            }
            onClick={() => setCollapsed((c) => !c)}
          >
            {collapsed ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
          </button>
        </header>
        {!collapsed && selected && it && (
          <div className="hud-row">
            <label>
              <span>Size · {Math.round(it.s * 100)}%</span>
              <input
                type="range"
                min={0.6}
                max={1.6}
                step={0.05}
                value={it.s}
                onChange={(e) =>
                  setItem(selected, { s: Number(e.target.value) })
                }
              />
            </label>
            {HIDEABLE.includes(selected) && (
              <button
                type="button"
                className="chip"
                onClick={() => setItem(selected, { hidden: !it.hidden })}
              >
                {it.hidden ? <Eye size={15} /> : <EyeOff size={15} />}{" "}
                {it.hidden ? "Show" : "Hide"}
              </button>
            )}
          </div>
        )}
        {!collapsed && (
          <>
            <div className="hud-row">
              <label>
                <span>Opacity · {Math.round(draft.opacity * 100)}%</span>
                <input
                  type="range"
                  min={0.25}
                  max={1}
                  step={0.05}
                  value={draft.opacity}
                  onChange={(e) =>
                    setDraft((d) => ({ ...d, opacity: Number(e.target.value) }))
                  }
                />
              </label>
              <label>
                <span>All controls · {Math.round(draft.scale * 100)}%</span>
                <input
                  type="range"
                  min={0.7}
                  max={1.4}
                  step={0.05}
                  value={draft.scale}
                  onChange={(e) =>
                    setDraft((d) => ({ ...d, scale: Number(e.target.value) }))
                  }
                />
              </label>
            </div>
            <div className="hud-row presets">
              {HUD_PRESETS.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  className="chip"
                  onClick={() => setDraft((d) => ({ ...d, layout: p.layout }))}
                >
                  <LayoutGrid size={14} /> {p.name}
                </button>
              ))}
              <button
                type="button"
                className="chip"
                onClick={() =>
                  setDraft((d) => ({ ...d, layout: mirror(d.layout) }))
                }
              >
                <FlipHorizontal2 size={14} /> Mirror
              </button>
              <button
                type="button"
                className="chip"
                onClick={() =>
                  setDraft((d) => ({
                    ...d,
                    layout: CLASSIC,
                    opacity: DEFAULT_HUD.opacity,
                    scale: 1,
                  }))
                }
              >
                <RotateCcw size={14} /> Reset
              </button>
            </div>
          </>
        )}
        <footer>
          <button type="button" className="text-button" onClick={onCancel}>
            <X size={16} /> CANCEL
          </button>
          <button
            type="button"
            className="primary"
            onClick={() => onSave(draft)}
          >
            SAVE LAYOUT <Check size={18} />
          </button>
        </footer>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Settings dialog                                                    */
/* ------------------------------------------------------------------ */

function Toggle({
  label,
  note,
  checked,
  onChange,
}: {
  label: string;
  note?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="setting-toggle">
      <span>
        {label}
        {note && <small>{note}</small>}
      </span>
      <input
        type="checkbox"
        role="switch"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      <i aria-hidden="true" />
    </label>
  );
}

export function SettingsDialog({
  hud,
  onChange,
  onCustomize,
  onClose,
}: {
  hud: HudSettings;
  onChange: (next: HudSettings) => void;
  onCustomize: () => void;
  onClose: () => void;
}) {
  const canVibrate = typeof navigator !== "undefined" && "vibrate" in navigator;
  const activePreset = HUD_PRESETS.find(
    (p) => JSON.stringify(p.layout) === JSON.stringify(hud.layout),
  )?.id;
  return (
    <div className="modal-backdrop">
      <section
        className="dialog settings-dialog"
        role="dialog"
        aria-modal="true"
        aria-label="Settings"
      >
        <button className="close" aria-label="Close settings" onClick={onClose}>
          <X />
        </button>
        <span className="edition">SETTINGS</span>
        <h2>CUSTOM HUD.</h2>
        <p>
          Arrange the touch controls the way your thumbs like them. Changes are
          saved on this device.
        </p>
        <div className="settings-preview">
          <div className="settings-mini" aria-hidden="true">
            {HUD_KEYS.filter((k) => !hud.layout[k].hidden).map((k) => (
              <i
                key={k}
                className={`mini-${k}`}
                style={{
                  left: `${hud.layout[k].x}%`,
                  top: `${hud.layout[k].y}%`,
                  width: `${HUD_BASE[k] * hud.layout[k].s * hud.scale * 7}%`,
                  opacity: hud.opacity,
                }}
              />
            ))}
          </div>
          <button type="button" className="primary" onClick={onCustomize}>
            CUSTOMIZE LAYOUT <LayoutGrid size={18} />
          </button>
        </div>
        <div
          className="settings-presets"
          role="radiogroup"
          aria-label="Layout preset"
        >
          {HUD_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              role="radio"
              aria-checked={activePreset === p.id}
              className={`chip${activePreset === p.id ? " active" : ""}`}
              onClick={() => onChange({ ...hud, layout: p.layout })}
            >
              {p.name}
            </button>
          ))}
          {!activePreset && <span className="chip active">Custom</span>}
        </div>
        <div className="settings-sliders">
          <label>
            <span>Button opacity · {Math.round(hud.opacity * 100)}%</span>
            <input
              type="range"
              min={0.25}
              max={1}
              step={0.05}
              value={hud.opacity}
              onChange={(e) =>
                onChange({ ...hud, opacity: Number(e.target.value) })
              }
            />
          </label>
          <label>
            <span>Button size · {Math.round(hud.scale * 100)}%</span>
            <input
              type="range"
              min={0.7}
              max={1.4}
              step={0.05}
              value={hud.scale}
              onChange={(e) =>
                onChange({ ...hud, scale: Number(e.target.value) })
              }
            />
          </label>
        </div>
        <div className="settings-toggles">
          <Toggle
            label="Button labels"
            checked={hud.labels}
            onChange={(v) => onChange({ ...hud, labels: v })}
          />
          <Toggle
            label="Combo counter"
            note="Shows hit streaks"
            checked={hud.combo}
            onChange={(v) => onChange({ ...hud, combo: v })}
          />
          <Toggle
            label="Health numbers"
            checked={hud.hpNumbers}
            onChange={(v) => onChange({ ...hud, hpNumbers: v })}
          />
          {canVibrate && (
            <Toggle
              label="Vibration"
              note="Buzz on button press and hits"
              checked={hud.haptics}
              onChange={(v) => onChange({ ...hud, haptics: v })}
            />
          )}
        </div>
        <div className="settings-footer">
          <button
            type="button"
            className="text-button"
            onClick={() => onChange(DEFAULT_HUD)}
          >
            <RotateCcw size={15} /> RESET TO DEFAULT
          </button>
          <button type="button" className="primary" onClick={onClose}>
            DONE <Check size={18} />
          </button>
        </div>
      </section>
    </div>
  );
}
