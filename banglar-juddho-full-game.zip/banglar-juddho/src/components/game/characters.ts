/**
 * Procedural p5.js fighter models for Banglar Juddho.
 *
 * The four models (Sheikh Hasina, Dr. Yunus, Tareq Rahman, Salauddin Ahmed)
 * are ported from the supplied standalone p5.js character projects and placed
 * on one shared, articulated skeleton so they animate consistently in-game:
 *   - two-bone IK arms and legs (hands/feet are posed, elbows/knees solve)
 *   - anticipation → strike → hold → recovery curves for every attack
 *   - facial expressions (brows, eyelids, gaze, mouth) and blinking
 *   - hurt flinch, knockback fall-and-recover, KO collapse and victory
 *
 * Every model draws at its ground anchor (0, 0) facing +x in native pixel
 * units; the caller translates, mirrors and scales (see MODEL_HEIGHT).
 */
import type p5 from 'p5'

export type Anim =
  | 'idle'
  | 'walk'
  | 'lightPunch'
  | 'heavyPunch'
  | 'frontKick'
  | 'heavyKick'
  | 'block'
  | 'jump'
  | 'hurt'
  | 'knockback'
  | 'special'
  | 'aim'
  | 'victory'
  | 'ko'

/** Animation lengths in seconds. Looping animations wrap; others hold their last frame. */
export const ANIM_LEN: Record<Anim, { len: number; loop: boolean }> = {
  idle: { len: 1.1, loop: true },
  walk: { len: 0.66, loop: true },
  lightPunch: { len: 0.35, loop: false },
  heavyPunch: { len: 0.5, loop: false },
  frontKick: { len: 0.38, loop: false },
  heavyKick: { len: 0.52, loop: false },
  block: { len: 0.5, loop: true },
  jump: { len: 0.65, loop: false },
  hurt: { len: 0.34, loop: false },
  knockback: { len: 0.9, loop: false },
  special: { len: 1.8, loop: false },
  aim: { len: 0.7, loop: false },
  victory: { len: 1.2, loop: true },
  ko: { len: 1.1, loop: false },
}

/** Native top-of-head heights, used to normalise the four models to one on-screen size. */
export const MODEL_HEIGHT = [386, 378, 326, 310]

type Vec = { x: number; y: number }
type RGB = readonly [number, number, number]
type Mouth = 'soft' | 'grit' | 'open' | 'pain' | 'tight' | 'smile' | 'flat'
export type Expr = { brow: number; eye: number; mouth: Mouth; gaze: number; blush: number }

export type Pose = {
  bob: number
  drop: number
  lean: number
  air: number
  hipShift: number
  fall: number
  headTilt: number
  /** Hand targets relative to each shoulder, in units of arm reach. [front, back] */
  hands: [Vec, Vec]
  /** Foot targets: x in leg lengths from the anchor, y = lift above ground in leg lengths. [front, back] */
  feet: [Vec, Vec]
  smear: number
  smearLimb: 'front' | 'back' | 'kick' | null
  charge: number
  release: number
  weapon: number
  expr: Expr
}

export type DrawOptions = {
  /** Glow colour used for fist energy and special effects. */
  aura?: string
  /** Super meter full: fists hold a steady glow. */
  charged?: boolean
  reduced?: boolean
}

const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v))
const ease = (t: number) => t * t * (3 - 2 * t)
const easeOut = (t: number) => 1 - (1 - t) ** 3
const seg = (p: number, a: number, b: number) => clamp((p - a) / (b - a))
const mix = (a: number, b: number, t: number) => a + (b - a) * t
const mixV = (a: Vec, b: Vec, t: number): Vec => ({ x: mix(a.x, b.x, t), y: mix(a.y, b.y, t) })

/** Anticipation (-), fast strike to full extension (1), short hold, eased recovery. */
function strikeCurve(p: number, wind: number, hit: number, hold: number, back = 0.28) {
  if (p < wind) return -back * ease(p / wind)
  if (p < hit) return -back + (1 + back) * easeOut((p - wind) / (hit - wind))
  if (p < hold) return 1
  return 1 - ease((p - hold) / (1 - hold))
}

const GUARD_F: Vec = { x: 0.55, y: -0.24 }
const GUARD_B: Vec = { x: 0.32, y: -0.34 }
const STANCE_F: Vec = { x: 0.3, y: 0 }
const STANCE_B: Vec = { x: -0.3, y: 0 }

/** Samples an animation into a full skeleton pose. */
export function samplePose(anim: Anim, t: number, clock: number): Pose {
  const cfg = ANIM_LEN[anim]
  const raw = t / cfg.len
  const p = cfg.loop ? raw - Math.floor(raw) : clamp(raw)
  const breathe = Math.sin(clock * 3.1)
  const blinkPhase = (clock + 0.37) % 3.4
  const blink = blinkPhase < 0.13 ? 1 - Math.abs(blinkPhase - 0.065) / 0.065 : 0
  const P: Pose = {
    bob: breathe * 1.6,
    drop: 7,
    lean: 0.05,
    air: 0,
    hipShift: 0,
    fall: 0,
    headTilt: 0,
    hands: [{ ...GUARD_F, y: GUARD_F.y + breathe * 0.02 }, { ...GUARD_B, y: GUARD_B.y + breathe * 0.02 }],
    feet: [{ ...STANCE_F }, { ...STANCE_B }],
    smear: 0,
    smearLimb: null,
    charge: 0,
    release: 0,
    weapon: 0,
    expr: { brow: 0.5, eye: 1 - blink * 0.95, mouth: 'soft', gaze: 1, blush: 0 },
  }
  const e = P.expr
  const ph = p * Math.PI * 2

  switch (anim) {
    case 'idle':
      break
    case 'walk': {
      P.feet[0] = { x: 0.3 + Math.sin(ph) * 0.2, y: Math.max(0, Math.cos(ph)) * 0.13 }
      P.feet[1] = { x: -0.3 - Math.sin(ph) * 0.2, y: Math.max(0, -Math.cos(ph)) * 0.13 }
      P.bob = -Math.abs(Math.cos(ph)) * 3
      P.hands[0].y += Math.sin(ph) * 0.04
      P.hands[1].y -= Math.sin(ph) * 0.04
      P.lean = 0.08
      e.brow = 1
      break
    }
    case 'block': {
      const k = ease(seg(p, 0, 0.12))
      P.drop = 7 + 9 * k
      P.lean = mix(0.05, -0.07, k)
      P.hands[0] = mixV(GUARD_F, { x: 0.36, y: -0.66 }, k)
      P.hands[1] = mixV(GUARD_B, { x: 0.26, y: -0.58 }, k)
      P.feet[0].x = 0.34
      P.feet[1].x = -0.36
      P.headTilt = 0.08 * k
      Object.assign(e, { brow: 2, eye: Math.min(e.eye, 0.8), mouth: 'tight', gaze: 1 })
      break
    }
    case 'lightPunch': {
      // Lead-hand jab.
      const s = strikeCurve(p, 0.17, 0.4, 0.55)
      const out = Math.max(0, s)
      P.hands[0] = mixV({ x: GUARD_F.x + Math.min(0, s) * 0.5, y: GUARD_F.y + Math.min(0, s) * -0.1 }, { x: 1.1, y: -0.12 }, out)
      P.hands[1] = { x: GUARD_B.x - out * 0.08, y: GUARD_B.y - out * 0.04 }
      P.lean = 0.05 + 0.12 * out
      P.hipShift = 7 * s
      P.smear = p > 0.22 && p < 0.5 ? out : 0
      P.smearLimb = 'front'
      Object.assign(e, { brow: 2.5, eye: 0.85, mouth: 'grit', gaze: 2 })
      break
    }
    case 'heavyPunch': {
      // Rear cross with a lunge step: big wind-up, full-body follow-through.
      const s = strikeCurve(p, 0.32, 0.5, 0.66, 0.45)
      const out = Math.max(0, s)
      const wind = Math.max(0, -s)
      P.hands[1] = mixV({ x: GUARD_B.x - wind * 0.45, y: GUARD_B.y + wind * 0.2 }, { x: 1.32, y: -0.1 }, out)
      P.hands[0] = mixV(GUARD_F, { x: 0.2, y: -0.05 }, out)
      P.lean = 0.05 + 0.26 * out - 0.12 * wind
      P.hipShift = 20 * out - 8 * wind
      P.drop = 7 + 6 * out + 4 * wind
      P.feet[0].x = 0.3 + 0.22 * out
      P.smear = p > 0.34 && p < 0.62 ? out : 0
      P.smearLimb = 'back'
      Object.assign(e, { brow: 3.5, eye: 1.05, mouth: out > 0.3 ? 'open' : 'grit', gaze: 3 })
      break
    }
    case 'frontKick':
    case 'heavyKick': {
      const heavy = anim === 'heavyKick'
      const s = heavy ? strikeCurve(p, 0.26, 0.48, 0.64, 0.4) : strikeCurve(p, 0.15, 0.4, 0.58)
      const out = Math.max(0, s)
      const chamber = ease(seg(p, 0, heavy ? 0.3 : 0.2)) * (1 - ease(seg(p, 0.62, 1)))
      P.feet[0] = {
        x: 0.3 + chamber * 0.12 + out * (heavy ? 0.66 : 0.74),
        y: chamber * 0.5 + out * (heavy ? 0.78 : 0.4),
      }
      P.feet[1] = { x: -0.32 - out * 0.06, y: 0 }
      P.lean = 0.05 - (heavy ? 0.36 : 0.2) * out - chamber * 0.06
      P.hipShift = (heavy ? 10 : 6) * out
      P.drop = 7 + 3 * chamber
      P.hands[0] = mixV(GUARD_F, { x: 0.25, y: 0.1 }, out)
      P.hands[1] = mixV(GUARD_B, { x: 0.48, y: -0.42 }, out)
      P.smear = p > 0.2 && p < 0.6 ? out : 0
      P.smearLimb = 'kick'
      Object.assign(e, { brow: heavy ? 3.5 : 2.5, eye: 0.9, mouth: heavy ? 'open' : 'grit', gaze: 2 })
      break
    }
    case 'jump': {
      const k = Math.sin(p * Math.PI)
      P.air = k * 92
      const tuck = ease(seg(p, 0.05, 0.35)) * (1 - ease(seg(p, 0.7, 1)))
      P.feet[0] = { x: 0.3 - tuck * 0.05, y: tuck * 0.42 }
      P.feet[1] = { x: -0.3 + tuck * 0.18, y: tuck * 0.3 }
      P.hands[0] = mixV(GUARD_F, { x: 0.62, y: -0.42 }, tuck)
      P.hands[1] = mixV(GUARD_B, { x: 0.1, y: -0.55 }, tuck)
      P.drop = 7 - tuck * 4 + (1 - k) * 4
      Object.assign(e, { brow: 2, mouth: 'tight', gaze: 1.5 })
      break
    }
    case 'hurt': {
      const r = Math.sin(Math.min(1, p * 1.35) * Math.PI)
      P.lean = 0.05 - 0.32 * r
      P.hipShift = -12 * r
      P.headTilt = -0.34 * r
      P.hands[0] = mixV(GUARD_F, { x: 0.15, y: 0.5 }, r)
      P.hands[1] = mixV(GUARD_B, { x: -0.25, y: 0.4 }, r)
      P.feet[0].x = 0.3 - 0.1 * r
      P.drop = 7 + 5 * r
      Object.assign(e, { brow: -3, eye: 1.25, mouth: 'pain', gaze: -1 })
      break
    }
    case 'knockback': {
      const up = p < 0.42 ? easeOut(p / 0.42) : 1 - ease((p - 0.42) / 0.58)
      P.fall = up * 1.05
      P.air = Math.sin(seg(p, 0, 0.35) * Math.PI) * 24
      P.hipShift = -14 * up
      P.headTilt = -0.4 * up
      P.hands[0] = mixV(GUARD_F, { x: -0.1, y: -0.55 }, up)
      P.hands[1] = mixV(GUARD_B, { x: -0.4, y: -0.45 }, up)
      P.feet[0] = { x: 0.3 + up * 0.28, y: up * 0.3 }
      Object.assign(e, { brow: -3.5, eye: p > 0.15 && p < 0.55 ? 0.15 : 1.2, mouth: 'pain', gaze: -1 })
      break
    }
    case 'special': {
      // Charge (crouch, gather energy) → release (two-hand thrust) → recover.
      const c = ease(seg(p, 0, 0.36))
      const rel = ease(seg(p, 0.4, 0.5)) * (1 - ease(seg(p, 0.74, 1)))
      P.charge = c * (1 - ease(seg(p, 0.42, 0.5)))
      P.release = rel
      P.drop = 7 + 22 * c * (1 - rel) + 6 * rel
      P.lean = 0.05 - 0.1 * c * (1 - rel) + 0.24 * rel
      P.hipShift = 16 * rel
      const gatherF = { x: -0.12, y: 0.5 }
      const gatherB = { x: -0.22, y: 0.46 }
      P.hands[0] = mixV(mixV(GUARD_F, gatherF, c), { x: 1.18, y: -0.18 }, rel)
      P.hands[1] = mixV(mixV(GUARD_B, gatherB, c), { x: 1.08, y: 0.02 }, rel)
      P.feet[0].x = 0.3 + 0.16 * rel
      P.feet[1].x = -0.34 - 0.06 * c
      Object.assign(e, {
        brow: 4,
        eye: rel > 0.2 ? 1.12 : 0.65,
        mouth: rel > 0.2 ? 'open' : 'grit',
        gaze: 3,
      })
      break
    }
    case 'aim': {
      const k = ease(seg(p, 0, 0.12))
      const kick = Math.max(0, Math.sin(t * 34)) * 0.05 * k
      P.hands[0] = mixV(GUARD_F, { x: 0.98 - kick, y: -0.02 }, k)
      P.hands[1] = mixV(GUARD_B, { x: 0.72 - kick, y: 0.08 }, k)
      P.weapon = k
      P.lean = 0.08 - kick
      P.drop = 11
      Object.assign(e, { brow: 3, eye: 0.7, mouth: 'tight', gaze: 3 })
      break
    }
    case 'victory': {
      const bounce = Math.abs(Math.sin(ph))
      P.drop = 4 - bounce * 4
      P.bob = 0
      P.lean = -0.04
      P.hands[0] = { x: 0.22 + Math.sin(ph) * 0.05, y: -1.0 + bounce * 0.12 }
      P.hands[1] = { x: -0.18, y: 0.3 }
      P.feet[0].x = 0.22
      P.feet[1].x = -0.22
      Object.assign(e, { brow: -1, eye: 1 - blink, mouth: 'smile', gaze: 0, blush: 1 })
      break
    }
    case 'ko': {
      const k = ease(clamp(p / 0.72))
      const settle = Math.sin(seg(p, 0.72, 1) * Math.PI) * 0.06
      P.fall = k * 1.48 - settle
      P.headTilt = -0.25 * k
      P.lean = 0.05 - 0.1 * k
      P.bob = 0
      P.drop = 7 + 8 * k
      P.hands[0] = mixV(GUARD_F, { x: -0.5, y: 0.55 }, k)
      P.hands[1] = mixV(GUARD_B, { x: -0.72, y: 0.3 }, k)
      P.feet[0] = { x: 0.3 + 0.12 * k, y: 0.1 * k }
      Object.assign(e, { brow: -2, eye: k > 0.4 ? 0.05 : 1.2, mouth: k > 0.4 ? 'flat' : 'pain', gaze: 0 })
      break
    }
  }
  return P
}

/* ------------------------------------------------------------------ */
/*  Shared drawing helpers                                             */
/* ------------------------------------------------------------------ */

/** Two-bone IK. bend = +1 puts the joint below/behind the reach line, -1 in front. */
function ik(a: Vec, target: Vec, l1: number, l2: number, bend: number) {
  const dx = target.x - a.x
  const dy = target.y - a.y
  const d = clamp(Math.hypot(dx, dy), Math.abs(l1 - l2) + 0.01, l1 + l2 - 0.01)
  const ang = Math.atan2(dy, dx)
  const off = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1))
  const j = ang + bend * off
  const joint = { x: a.x + Math.cos(j) * l1, y: a.y + Math.sin(j) * l1 }
  const end = { x: a.x + Math.cos(ang) * d, y: a.y + Math.sin(ang) * d }
  return { joint, end }
}

const fill = (p: p5, c: RGB, a = 255) => p.fill(c[0], c[1], c[2], a)
const stroke = (p: p5, c: RGB, a = 255) => p.stroke(c[0], c[1], c[2], a)
const darker = (c: RGB, k = 0.82): RGB => [c[0] * k, c[1] * k, c[2] * k]

function limb(p: p5, a: Vec, b: Vec, w: number, col: RGB, outline: RGB | null = null) {
  p.strokeCap(p.ROUND)
  if (outline) {
    stroke(p, outline)
    p.strokeWeight(w + 3)
    p.line(a.x, a.y, b.x, b.y)
  } else {
    p.stroke(0, 0, 0, 38)
    p.strokeWeight(w + 3)
    p.line(a.x, a.y + 2, b.x, b.y + 2)
  }
  stroke(p, col)
  p.strokeWeight(w)
  p.line(a.x, a.y, b.x, b.y)
}

function fist(p: p5, h: Vec, skin: RGB, size: number, dir: number) {
  p.push()
  p.translate(h.x, h.y)
  p.rotate(dir)
  p.noStroke()
  fill(p, darker(skin, 0.86))
  p.ellipse(1, 1.5, size * 1.15, size)
  fill(p, skin)
  p.ellipse(0, 0, size * 1.12, size * 0.95)
  fill(p, [Math.min(255, skin[0] + 26), Math.min(255, skin[1] + 24), Math.min(255, skin[2] + 22)])
  p.ellipse(size * 0.14, -size * 0.2, size * 0.55, size * 0.32)
  stroke(p, darker(skin, 0.7))
  p.strokeWeight(1)
  p.line(size * 0.32, -size * 0.28, size * 0.32, size * 0.28)
  p.line(size * 0.1, -size * 0.36, size * 0.1, size * 0.34)
  p.pop()
}

type LegSeg = { hip: Vec; knee: Vec; ankle: Vec }
type ArmSeg = { sh: Vec; el: Vec; hand: Vec }

type Spec = {
  hip: number
  thigh: number
  shin: number
  foot: number
  stance: number
  shoulderX: number
  shoulderY: number
  upper: number
  fore: number
  neck: Vec
  leg(p: p5, l: LegSeg, back: boolean): void
  shoe(p: p5, ankle: Vec, ang: number, back: boolean): void
  arm(p: p5, a: ArmSeg, back: boolean, P: Pose): void
  lower?(p: p5, legs: LegSeg[], hip: Vec, P: Pose): void
  torso(p: p5, P: Pose): void
  head(p: p5, P: Pose): void
}

function hexRGB(hex: string): RGB {
  const n = parseInt(hex.replace('#', ''), 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

function drawRig(p: p5, s: Spec, P: Pose, o: DrawOptions) {
  const legL = s.thigh + s.shin
  const L = s.upper + s.fore
  const aura = hexRGB(o.aura ?? '#f2d18b')
  p.push()
  if (P.fall) {
    // Pivot on the back heel so the body topples backwards.
    p.translate(-22, 0)
    p.rotate(-P.fall)
    p.translate(22, 0)
  }
  p.translate(0, -P.air)
  const hip = { x: P.hipShift, y: s.hip + P.drop + P.bob }
  const legs: LegSeg[] = [0, 1].map((j) => {
    const h = { x: hip.x + (j ? -s.stance : s.stance), y: hip.y }
    const f = P.feet[j]
    const r = ik(h, { x: f.x * legL, y: s.foot - f.y * legL }, s.thigh, s.shin, -1)
    return { hip: h, knee: r.joint, ankle: r.end }
  })
  const arms: ArmSeg[] = [0, 1].map((j) => {
    const sh = { x: j ? -s.shoulderX : s.shoulderX, y: s.shoulderY }
    const t = P.hands[j]
    const r = ik(sh, { x: sh.x + t.x * L, y: sh.y + t.y * L }, s.upper, s.fore, 1)
    return { sh, el: r.joint, hand: r.end }
  })
  const torsoFrame = () => {
    p.translate(hip.x, hip.y - s.hip)
    p.translate(0, s.hip)
    p.rotate(P.lean)
    p.translate(0, -s.hip)
  }
  const shoeAngle = (l: LegSeg) => Math.atan2(l.ankle.y - l.knee.y, l.ankle.x - l.knee.x) - Math.PI / 2

  // Back arm (behind the body).
  p.push()
  torsoFrame()
  s.arm(p, arms[1], true, P)
  p.pop()

  // Legs.
  s.leg(p, legs[1], true)
  s.shoe(p, legs[1].ankle, shoeAngle(legs[1]), true)
  s.leg(p, legs[0], false)
  s.shoe(p, legs[0].ankle, shoeAngle(legs[0]), false)
  if (P.smear > 0 && P.smearLimb === 'kick' && !o.reduced) smearTrail(p, legs[0].ankle, P.smear, aura, -1)
  s.lower?.(p, legs, hip, P)

  // Torso, head, front arm.
  p.push()
  torsoFrame()
  s.torso(p, P)
  p.push()
  p.translate(s.neck.x, s.neck.y)
  p.rotate(P.headTilt)
  p.translate(-s.neck.x, -s.neck.y)
  s.head(p, P)
  p.pop()
  if (P.weapon > 0) drawRifle(p, arms[0].hand, P.weapon)
  s.arm(p, arms[0], false, P)

  // Fist energy and strike smears.
  if (P.smear > 0 && !o.reduced && P.smearLimb !== 'kick')
    smearTrail(p, arms[P.smearLimb === 'back' ? 1 : 0].hand, P.smear, aura, -1)
  const glow = Math.max(P.charge, P.release, o.charged ? 0.45 : 0)
  if (glow > 0) {
    for (const a of arms) fistGlow(p, a.hand, glow, aura, P, o.reduced)
  }
  p.pop()
  p.pop()
}

function smearTrail(p: p5, at: Vec, amt: number, col: RGB, dir: number) {
  p.noStroke()
  for (let k = 1; k <= 4; k++) {
    fill(p, [255, 236, 190], amt * 120 * (1 - k / 5))
    p.ellipse(at.x + dir * k * 13, at.y, 30 - k * 4, 20 - k * 3)
  }
  stroke(p, col, amt * 170)
  p.strokeWeight(2.5)
  p.noFill()
  p.arc(at.x - 18, at.y, 50, 44, -0.9, 0.9)
}

function fistGlow(p: p5, h: Vec, k: number, col: RGB, P: Pose, reduced?: boolean) {
  p.noStroke()
  const pulse = reduced ? 1 : 1 + Math.sin(P.bob * 2 + h.x) * 0.06
  for (let r = 3; r > 0; r--) {
    fill(p, col, (48 * k) / r + 10)
    const d = (26 + r * 14) * k * pulse + 10
    p.ellipse(h.x, h.y, d, d)
  }
  fill(p, [255, 244, 214], 200 * k)
  p.ellipse(h.x, h.y, 12 * k + 4, 12 * k + 4)
}

function drawRifle(p: p5, h: Vec, k: number) {
  p.push()
  p.translate(h.x - 24, h.y + 2)
  p.stroke(18, 24, 22)
  p.strokeWeight(1.6)
  p.fill(52, 70, 61, 255 * k)
  p.rect(0, -7, 78, 13, 2)
  p.fill(116, 92, 60, 255 * k)
  p.rect(6, 4, 13, 22, 2)
  p.rect(-22, -6, 24, 12, 3)
  p.fill(30, 36, 34, 255 * k)
  p.rect(36, 5, 8, 14, 2)
  p.pop()
}

/** Front-view eye pair with lids, iris highlight, brows and optional glasses. */
function eyesFront(
  p: p5,
  cx: number,
  cy: number,
  gap: number,
  e: Expr,
  o: { brow: RGB; iris: RGB; glasses?: RGB; lensW?: number; lensH?: number; browY?: number },
) {
  const eyeH = Math.max(0.7, 5 * e.eye)
  p.noStroke()
  for (const side of [-1, 1]) {
    const x = cx + side * gap
    p.fill(250, 245, 235)
    p.ellipse(x, cy, 10, eyeH + 2.5)
    fill(p, o.iris)
    p.ellipse(x + e.gaze, cy, 4, Math.max(0.8, eyeH - 0.5))
    if (e.eye > 0.3) {
      p.fill(255)
      p.circle(x + e.gaze - 1, cy - 1.4, 1.4)
    }
  }
  // Brows: inner ends drop for anger (brow > 0) and lift for pain (brow < 0).
  stroke(p, o.brow)
  p.strokeWeight(2.3)
  const by = cy - (o.browY ?? 8)
  p.line(cx - gap - 6, by - 1, cx - 3, by + e.brow * 0.9)
  p.line(cx + 3, by + e.brow * 0.9, cx + gap + 6, by - 1)
  if (o.glasses) {
    const w = o.lensW ?? 15
    const hgt = o.lensH ?? 11
    p.noFill()
    stroke(p, o.glasses)
    p.strokeWeight(1.7)
    p.rect(cx - gap - w / 2, cy - hgt / 2, w, hgt, 3.5)
    p.rect(cx + gap - w / 2, cy - hgt / 2, w, hgt, 3.5)
    p.line(cx - gap + w / 2, cy - 1, cx + gap - w / 2, cy - 1)
    p.stroke(205, 225, 235, 120)
    p.strokeWeight(0.8)
    p.line(cx - gap - w / 2 + 3, cy - hgt / 2 + 2.5, cx - gap + 1, cy - hgt / 2 + 2.5)
    p.line(cx + gap - w / 2 + 3, cy - hgt / 2 + 2.5, cx + gap + 1, cy - hgt / 2 + 2.5)
  }
}

function mouthFront(p: p5, cx: number, cy: number, e: Expr, lip: RGB, w = 12) {
  const m = e.mouth
  if (m === 'smile') {
    p.noFill()
    stroke(p, lip)
    p.strokeWeight(2)
    p.arc(cx, cy - 2, w * 1.5, 10, 0.15, Math.PI - 0.15)
    p.noStroke()
    p.fill(250)
    p.rect(cx - w * 0.45, cy + 0.5, w * 0.9, 2, 1)
  } else if (m === 'grit') {
    p.noStroke()
    fill(p, darker(lip, 0.9))
    p.rect(cx - w * 0.55, cy - 2.5, w * 1.1, 5, 2)
    p.fill(245)
    p.rect(cx - w * 0.42, cy - 2, w * 0.84, 2)
  } else if (m === 'open' || m === 'pain') {
    p.noStroke()
    fill(p, darker(lip, 0.8))
    p.ellipse(cx, cy, m === 'pain' ? w * 0.95 : w * 0.75, m === 'pain' ? 8 : 10)
    p.fill(230, 135, 125)
    p.ellipse(cx, cy + 2.5, w * 0.4, 3)
  } else if (m === 'tight') {
    stroke(p, lip)
    p.strokeWeight(2.2)
    p.line(cx - w * 0.55, cy, cx + w * 0.55, cy)
  } else if (m === 'flat') {
    stroke(p, lip)
    p.strokeWeight(1.5)
    p.line(cx - w * 0.4, cy + 1, cx + w * 0.4, cy - 1)
  } else {
    stroke(p, lip)
    p.strokeWeight(1.6)
    p.noFill()
    p.arc(cx, cy - 2, w, 5, 0.3, Math.PI - 0.3)
  }
}

/* ------------------------------------------------------------------ */
/*  0 · Sheikh Hasina — cream floral sari, orange-edged pallu, glasses */
/* ------------------------------------------------------------------ */

const H_SKIN: RGB = [223, 160, 126]
const H_SARI: RGB = [194, 190, 139]
const H_LEG: RGB = [184, 169, 119]
const H_EDGE: RGB = [231, 137, 83]

const hasina: Spec = {
  hip: -96,
  thigh: 48,
  shin: 46,
  foot: -6,
  stance: 7,
  shoulderX: 20,
  shoulderY: -246,
  upper: 45,
  fore: 41,
  neck: { x: 0, y: -290 },
  leg(p, l, back) {
    const c = back ? darker(H_LEG) : H_LEG
    limb(p, l.hip, l.knee, 15, c)
    limb(p, l.knee, l.ankle, 13, c)
  },
  shoe(p, a, ang, back) {
    p.push()
    p.translate(a.x, a.y)
    p.rotate(ang)
    p.noStroke()
    fill(p, back ? [170, 140, 85] : [198, 166, 103])
    p.ellipse(7, 1, 32, 10)
    fill(p, [238, 219, 166])
    p.ellipse(7, -2, 28, 7)
    fill(p, H_SKIN)
    p.ellipse(3, -4, 14, 6)
    p.pop()
  },
  arm(p, a, back, P) {
    const skin = back ? darker(H_SKIN, 0.88) : H_SKIN
    limb(p, a.sh, a.el, 13, skin)
    limb(p, a.el, a.hand, 11, skin)
    // Short blouse sleeve.
    const mid = mixV(a.sh, a.el, 0.45)
    limb(p, a.sh, mid, 15, back ? darker(H_SARI) : H_SARI)
    stroke(p, H_EDGE)
    p.strokeWeight(2)
    p.line(mid.x - 5, mid.y, mid.x + 5, mid.y)
    if (!back) {
      // Gold wristwatch.
      const w = mixV(a.el, a.hand, 0.82)
      p.noStroke()
      p.fill(190, 155, 92)
      p.ellipse(w.x, w.y, 11, 7)
      p.fill(235, 230, 211)
      p.circle(w.x, w.y, 4.5)
    }
    fist(p, a.hand, skin, 14, P.release > 0.3 ? 0 : -0.2)
  },
  lower(p, legs, hip, P) {
    // Sari skirt flares with the knees, so kicks lift the drape.
    const [f, b] = legs
    const top = hip.y - 150 - P.drop * 0.2
    const backHem = { x: Math.min(b.knee.x - 10, hip.x - 32), y: Math.max(b.knee.y + 14, hip.y + 8) }
    const frontHem = { x: Math.max(f.knee.x + 10, hip.x + 33), y: Math.min(hip.y + 8, f.knee.y + 14) }
    p.push()
    p.translate(hip.x, 0)
    p.rotate(P.lean * 0.4)
    p.translate(-hip.x, 0)
    p.noStroke()
    fill(p, [190, 188, 137])
    p.beginShape()
    p.vertex(hip.x - 27, top)
    p.bezierVertex(hip.x - 40, top + 50, backHem.x - 2, backHem.y - 50, backHem.x, backHem.y)
    p.bezierVertex(backHem.x + 20, backHem.y + 9, frontHem.x - 20, frontHem.y + 9, frontHem.x, frontHem.y)
    p.bezierVertex(frontHem.x + 2, frontHem.y - 50, hip.x + 38, top + 50, hip.x + 25, top)
    p.endShape(p.CLOSE)
    for (let i = 0; i < 7; i++) {
      const t = i / 6
      stroke(p, [157, 151, 105], 120)
      p.strokeWeight(1.1)
      p.line(mix(hip.x - 22, hip.x + 20, t), top + 60, mix(backHem.x + 6, frontHem.x - 6, t), mix(backHem.y, frontHem.y, t) - 2)
    }
    // Orange border along the hem.
    p.noFill()
    stroke(p, H_EDGE)
    p.strokeWeight(5)
    p.bezier(backHem.x, backHem.y, backHem.x + 20, backHem.y + 9, frontHem.x - 20, frontHem.y + 9, frontHem.x, frontHem.y)
    stroke(p, [250, 205, 143])
    p.strokeWeight(1.3)
    p.bezier(backHem.x, backHem.y - 4, backHem.x + 20, backHem.y + 5, frontHem.x - 20, frontHem.y + 5, frontHem.x, frontHem.y - 4)
    p.pop()
  },
  torso(p) {
    p.noStroke()
    fill(p, H_SARI)
    p.beginShape()
    p.vertex(-25, -276)
    p.bezierVertex(-43, -258, -38, -221, -31, -190)
    p.vertex(-26, -140)
    p.bezierVertex(-6, -128, 20, -134, 31, -146)
    p.vertex(34, -225)
    p.bezierVertex(34, -258, 20, -277, 8, -282)
    p.endShape(p.CLOSE)
    // Pallu diagonal over the shoulder.
    fill(p, [224, 211, 160])
    p.beginShape()
    p.vertex(-28, -272)
    p.bezierVertex(-55, -245, -47, -218, -35, -190)
    p.vertex(18, -136)
    p.vertex(32, -151)
    p.vertex(-5, -218)
    p.bezierVertex(12, -246, 9, -266, -2, -280)
    p.endShape(p.CLOSE)
    // Floral motifs.
    p.noStroke()
    for (let yy = -262; yy < -146; yy += 17) {
      for (let xx = -22; xx <= 22; xx += 14) {
        const ox = (yy / 17) % 2 ? 3 : 0
        p.fill(242, 231, 194, 190)
        p.ellipse(xx + ox, yy, 4, 7)
        p.ellipse(xx + ox, yy, 7, 3)
        p.fill(218, 133, 85, 190)
        p.circle(xx + ox + 3, yy + 4, 2.5)
      }
    }
    p.noFill()
    stroke(p, H_EDGE)
    p.strokeWeight(5)
    p.beginShape()
    p.vertex(-29, -272)
    p.bezierVertex(-51, -240, -42, -210, -30, -187)
    p.vertex(20, -137)
    p.endShape()
    stroke(p, [250, 205, 143])
    p.strokeWeight(1.4)
    p.line(-31, -264, -44, -232)
    // Neck.
    p.noStroke()
    fill(p, [205, 151, 119])
    p.rect(-8, -296, 16, 26, 5)
    // Pearl necklace.
    p.noFill()
    p.stroke(250, 244, 220)
    p.strokeWeight(2)
    p.arc(0, -266, 34, 24, 0.1, Math.PI - 0.1)
    p.noStroke()
    for (let a = 0.2; a < Math.PI - 0.1; a += 0.32) {
      p.fill(255, 248, 229)
      p.circle(Math.cos(a) * 17, -266 + Math.sin(a) * 12, 3.2)
    }
    // Green brooch.
    p.fill(30, 105, 70)
    p.stroke(212, 170, 65)
    p.strokeWeight(1)
    p.rect(12, -250, 13, 8, 2)
    p.noStroke()
    p.fill(220, 175, 65)
    p.circle(18.5, -246, 3)
  },
  head(p, P) {
    const e = P.expr
    p.noStroke()
    // Pallu trailing behind the head.
    fill(p, [226, 170, 111])
    p.beginShape()
    p.vertex(-22, -352)
    p.bezierVertex(-40, -330, -40, -300, -30, -276)
    p.vertex(-18, -282)
    p.bezierVertex(-26, -306, -24, -330, -14, -346)
    p.endShape(p.CLOSE)
    // Face.
    fill(p, [218, 163, 132])
    p.beginShape()
    p.vertex(-19, -343)
    p.bezierVertex(-22, -371, 19, -379, 23, -347)
    p.vertex(22, -316)
    p.bezierVertex(19, -300, 9, -292, 0, -292)
    p.bezierVertex(-10, -292, -19, -302, -21, -318)
    p.endShape(p.CLOSE)
    p.fill(206, 150, 120)
    p.ellipse(-21, -324, 7, 12)
    p.ellipse(22, -324, 7, 12)
    // Grey hair under the head covering.
    p.fill(187, 187, 177)
    p.arc(0, -344, 44, 34, Math.PI, Math.PI * 2, p.CHORD)
    p.fill(206, 205, 196)
    p.arc(-6, -346, 22, 14, Math.PI, Math.PI * 2, p.CHORD)
    // Cheeks.
    p.fill(222, 140, 118, e.blush ? 140 : 60)
    p.ellipse(-12, -317, 8, 5)
    p.ellipse(13, -317, 8, 5)
    eyesFront(p, 0.5, -330, 9.5, e, {
      brow: [92, 80, 70],
      iris: [55, 45, 40],
      glasses: [68, 55, 48],
      lensW: 15,
      lensH: 10,
      browY: 9,
    })
    // Nose and mouth.
    p.stroke(176, 112, 88)
    p.strokeWeight(1.2)
    p.line(1, -326, -1, -316)
    p.line(-1, -316, 3, -315)
    mouthFront(p, 0.5, -306, e, [150, 76, 68], 11)
    // Head covering: orange-edged pallu framing the face.
    p.noStroke()
    fill(p, [226, 170, 111])
    p.beginShape()
    p.vertex(-24, -340)
    p.bezierVertex(-34, -368, -16, -386, 7, -380)
    p.bezierVertex(29, -373, 33, -351, 27, -333)
    p.vertex(31, -300)
    p.vertex(22, -292)
    p.vertex(19, -337)
    p.bezierVertex(10, -359, -7, -362, -18, -342)
    p.endShape(p.CLOSE)
    p.fill(243, 221, 176, 220)
    p.beginShape()
    p.vertex(-24, -344)
    p.bezierVertex(-30, -366, -12, -379, 8, -374)
    p.bezierVertex(26, -368, 29, -350, 24, -337)
    p.bezierVertex(10, -350, -9, -350, -24, -344)
    p.endShape(p.CLOSE)
    p.noFill()
    stroke(p, [220, 128, 76])
    p.strokeWeight(2.4)
    p.arc(1, -350, 54, 56, Math.PI * 1.05, Math.PI * 1.95)
    // Earring.
    p.noStroke()
    p.fill(222, 178, 78)
    p.circle(-22, -316, 3.2)
  },
}

/* ------------------------------------------------------------------ */
/*  1 · Dr. Yunus — blue checked panjabi, beige vest, silver hair      */
/* ------------------------------------------------------------------ */

const Y_SKIN: RGB = [180, 127, 98]
const Y_BLUE: RGB = [38, 79, 139]
const Y_TROUSER: RGB = [230, 223, 207]
const checkCache = new WeakMap<p5, p5.Graphics>()

function checkTexture(p: p5) {
  let g = checkCache.get(p)
  if (!g) {
    g = p.createGraphics(96, 96)
    g.pixelDensity(1)
    g.background(34, 79, 139)
    g.stroke(123, 165, 207)
    g.strokeWeight(2)
    for (let x = 0; x <= 96; x += 8) g.line(x, 0, x, 96)
    for (let y = 0; y <= 96; y += 8) g.line(0, y, 96, y)
    g.stroke(17, 47, 91)
    g.strokeWeight(1)
    for (let x = 4; x <= 96; x += 16) g.line(x, 0, x, 96)
    for (let y = 4; y <= 96; y += 16) g.line(0, y, 96, y)
    checkCache.set(p, g)
  }
  return g
}

const yunus: Spec = {
  hip: -98,
  thigh: 52,
  shin: 48,
  foot: -6,
  stance: 8,
  shoulderX: 25,
  shoulderY: -255,
  upper: 53,
  fore: 45,
  neck: { x: 0, y: -290 },
  leg(p, l, back) {
    const c = back ? darker(Y_TROUSER, 0.86) : Y_TROUSER
    limb(p, l.hip, l.knee, 16, c)
    limb(p, l.knee, l.ankle, 14, c)
    p.stroke(190, 182, 165, 120)
    p.strokeWeight(1)
    p.line(l.knee.x - 3, l.knee.y, l.ankle.x - 3, l.ankle.y)
  },
  shoe(p, a, ang, back) {
    p.push()
    p.translate(a.x - 6, a.y + 1)
    p.rotate(ang)
    p.noStroke()
    p.fill(back ? 18 : 25, back ? 19 : 27, back ? 22 : 31)
    p.beginShape()
    p.vertex(-8, -5)
    p.vertex(5, -11)
    p.vertex(25, -9)
    p.vertex(37, -2)
    p.vertex(34, 6)
    p.vertex(-7, 6)
    p.endShape(p.CLOSE)
    p.stroke(119, 121, 125)
    p.strokeWeight(1)
    p.line(4, -5, 28, -4)
    p.pop()
  },
  arm(p, a, back, P) {
    const c = back ? darker(Y_BLUE) : Y_BLUE
    limb(p, a.sh, a.el, 17, c)
    limb(p, a.el, a.hand, 15, c)
    const cuff = mixV(a.el, a.hand, 0.9)
    stroke(p, [123, 165, 207])
    p.strokeWeight(2)
    p.point(cuff.x, cuff.y)
    fist(p, a.hand, back ? darker(Y_SKIN, 0.9) : Y_SKIN, 19, P.release > 0.3 ? 0 : -0.15)
  },
  torso(p) {
    // Blue checked panjabi.
    p.noStroke()
    fill(p, Y_BLUE)
    const shape: [number, number][] = [
      [-30, -276],
      [30, -276],
      [39, -150],
      [35, -84],
      [-35, -84],
      [-39, -150],
    ]
    p.beginShape()
    for (const [x, y] of shape) p.vertex(x, y)
    p.endShape(p.CLOSE)
    const ctx = p.drawingContext as CanvasRenderingContext2D
    ctx.save()
    ctx.beginPath()
    shape.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)))
    ctx.closePath()
    ctx.clip()
    const tex = checkTexture(p)
    p.image(tex, -48, -280, 96, 100)
    p.image(tex, -48, -180, 96, 100)
    ctx.restore()
    // Side slit and hem shadow.
    p.stroke(17, 47, 91)
    p.strokeWeight(1.5)
    p.line(36, -84, 37, -112)
    p.line(-35, -84, -37, -112)
    p.noStroke()
    p.fill(0, 0, 0, 30)
    p.rect(-35, -90, 70, 6)
    // Beige sleeveless vest.
    p.fill(224, 213, 192)
    p.beginShape()
    p.vertex(-30, -270)
    p.vertex(-14, -280)
    p.vertex(0, -261)
    p.vertex(14, -280)
    p.vertex(30, -270)
    p.vertex(35, -146)
    p.vertex(25, -140)
    p.vertex(3, -140)
    p.vertex(0, -155)
    p.vertex(-4, -140)
    p.vertex(-27, -140)
    p.vertex(-35, -147)
    p.endShape(p.CLOSE)
    p.fill(244, 234, 214, 95)
    p.quad(-25, -264, -5, -253, -10, -146, -29, -146)
    p.stroke(177, 164, 143)
    p.strokeWeight(1.3)
    p.noFill()
    p.line(0, -261, 0, -156)
    p.noStroke()
    p.fill(154, 139, 116)
    for (const yy of [-239, -210, -181]) p.ellipse(7, yy, 5, 5)
    p.noFill()
    p.stroke(185, 170, 147)
    p.rect(12, -248, 13, 20)
    p.line(12, -242, 25, -242)
    // Neck.
    p.noStroke()
    p.fill(169, 116, 88)
    p.rect(-11, -298, 23, 30, 6)
  },
  head(p, P) {
    const e = P.expr
    p.noStroke()
    // Profile head; the nose points toward the opponent.
    p.fill(183, 132, 103)
    p.beginShape()
    p.vertex(-22, -342)
    p.bezierVertex(-19, -372, 20, -376, 31, -347)
    p.vertex(29, -315)
    p.vertex(40, -305)
    p.vertex(28, -299)
    p.vertex(22, -283)
    p.vertex(-10, -285)
    p.vertex(-23, -306)
    p.endShape(p.CLOSE)
    p.fill(171, 117, 91)
    p.ellipse(-14, -319, 11, 17)
    p.fill(150, 100, 78)
    p.ellipse(-14, -319, 5, 9)
    // Nose.
    p.fill(199, 149, 117)
    p.triangle(27, -318, 43, -306, 27, -302)
    p.stroke(109, 73, 58)
    p.strokeWeight(1.6)
    p.line(29, -305, 35, -305)
    // Cheek and smile lines.
    p.stroke(139, 91, 72, 150)
    p.strokeWeight(1)
    p.line(14, -309, 20, -300)
    p.fill(210, 120, 100, e.blush ? 120 : 0)
    p.noStroke()
    p.ellipse(14, -306, 10, 6)
    // Eye with lids.
    const eyeH = Math.max(0.8, 5.5 * e.eye)
    p.fill(245, 236, 222)
    p.ellipse(23, -318, 9, eyeH + 1.5)
    p.fill(43, 36, 31)
    p.ellipse(24 + e.gaze * 0.5, -318, 4, Math.max(0.8, eyeH - 0.6))
    if (e.eye > 0.3) {
      p.fill(255)
      p.circle(23.5 + e.gaze * 0.5, -319.5, 1.3)
    }
    // Bushy grey brow.
    p.stroke(96, 92, 86)
    p.strokeWeight(3.2)
    p.line(13, -325 - e.brow * 0.25, 29, -325 + e.brow * 0.8)
    // Mouth in profile.
    const m = e.mouth
    if (m === 'smile') {
      p.noFill()
      p.stroke(109, 63, 52)
      p.strokeWeight(2)
      p.arc(22, -297, 16, 8, 0.1, Math.PI * 0.75)
    } else if (m === 'open' || m === 'pain') {
      p.noStroke()
      p.fill(92, 44, 40)
      p.ellipse(25, -295, m === 'pain' ? 9 : 8, m === 'pain' ? 7 : 9)
    } else if (m === 'grit') {
      p.noStroke()
      p.fill(92, 44, 40)
      p.rect(17, -298, 11, 5, 2)
      p.fill(240)
      p.rect(18, -297.5, 9, 2)
    } else {
      p.stroke(109, 73, 58)
      p.strokeWeight(m === 'tight' ? 2.4 : 1.8)
      p.line(15, -296, 28, m === 'flat' ? -296 : -294)
    }
    // Swept-back silver hair.
    p.noStroke()
    p.fill(174, 175, 170)
    p.beginShape()
    p.vertex(-24, -318)
    p.vertex(-27, -344)
    p.bezierVertex(-25, -372, 15, -379, 31, -351)
    p.vertex(31, -337)
    p.vertex(22, -343)
    p.vertex(12, -356)
    p.vertex(-8, -351)
    p.vertex(-19, -333)
    p.endShape(p.CLOSE)
    p.stroke(231, 229, 220)
    p.strokeWeight(1.6)
    p.noFill()
    for (let i = 0; i < 6; i++) p.arc(0, -350 + i * 2, 48 - i * 4, 25 - i * 2, Math.PI * 1.05, Math.PI * 1.95)
  },
}

/* ------------------------------------------------------------------ */
/*  2 · Tareq Rahman — charcoal suit, red tie, glasses, flag pin       */
/* ------------------------------------------------------------------ */

const T_SKIN: RGB = [218, 164, 132]
const T_SUIT: RGB = [40, 42, 48]
const T_LINE: RGB = [16, 17, 21]

const tareq: Spec = {
  hip: -118,
  thigh: 62,
  shin: 58,
  foot: -6,
  stance: 11,
  shoulderX: 34,
  shoulderY: -262,
  upper: 51,
  fore: 47,
  neck: { x: 0, y: -268 },
  leg(p, l, back) {
    const c = back ? darker(T_SUIT, 0.8) : [34, 35, 40]
    limb(p, l.hip, l.knee, 21, c as RGB, T_LINE)
    limb(p, l.knee, l.ankle, 18, c as RGB, T_LINE)
    p.stroke(70, 72, 80)
    p.strokeWeight(1)
    p.line(l.hip.x + 2, l.hip.y, l.knee.x + 2, l.knee.y)
  },
  shoe(p, a, ang, back) {
    p.push()
    p.translate(a.x, a.y)
    p.rotate(ang)
    p.noStroke()
    p.fill(back ? 8 : 12, back ? 9 : 14, back ? 12 : 18)
    p.ellipse(8, 2, 38, 13)
    p.fill(back ? 35 : 48)
    p.ellipse(8, -1, 32, 9)
    p.fill(120, 120, 128, 120)
    p.ellipse(16, -3, 9, 3)
    p.pop()
  },
  arm(p, a, back, P) {
    const c = back ? darker(T_SUIT, 0.8) : T_SUIT
    limb(p, a.sh, a.el, 20, c, T_LINE)
    limb(p, a.el, a.hand, 17, c, T_LINE)
    const cuff = mixV(a.el, a.hand, 0.92)
    p.stroke(245)
    p.strokeWeight(6)
    p.point(cuff.x, cuff.y)
    fist(p, a.hand, back ? darker(T_SKIN, 0.9) : T_SKIN, 18, P.release > 0.3 ? 0 : -0.15)
  },
  torso(p) {
    // Trouser waist under the jacket hem.
    p.noStroke()
    p.fill(34, 35, 40)
    p.rect(-24, -140, 48, 30, 6)
    p.fill(245)
    p.quad(-28, -270, 28, -270, 21, -145, -21, -145)
    fill(p, [39, 41, 47])
    stroke(p, [15, 17, 21])
    p.strokeWeight(2)
    p.beginShape()
    p.vertex(-28, -278)
    p.vertex(-45, -265)
    p.vertex(-42, -166)
    p.vertex(-35, -128)
    p.vertex(0, -122)
    p.vertex(35, -128)
    p.vertex(42, -166)
    p.vertex(45, -265)
    p.vertex(28, -278)
    p.vertex(0, -254)
    p.endShape(p.CLOSE)
    // Lapels.
    p.noStroke()
    p.fill(17, 19, 24)
    p.triangle(-28, -278, -5, -250, -20, -214)
    p.triangle(28, -278, 5, -250, 20, -214)
    p.fill(255)
    p.triangle(-9, -267, 0, -251, -4, -238)
    p.triangle(9, -267, 0, -251, 4, -238)
    // Red tie.
    p.fill(174, 24, 38)
    p.triangle(-5, -260, 5, -260, 0, -268)
    p.beginShape()
    p.vertex(-5, -258)
    p.vertex(5, -258)
    p.vertex(8, -206)
    p.vertex(0, -194)
    p.vertex(-8, -206)
    p.endShape(p.CLOSE)
    p.fill(210, 60, 70, 140)
    p.triangle(-1, -256, 3, -256, 2, -214)
    // Seam, buttons, pocket square, flag pin, pockets.
    p.stroke(90)
    p.strokeWeight(1)
    p.line(0, -205, 0, -124)
    p.noStroke()
    p.fill(8)
    p.ellipse(5, -183, 4, 4)
    p.ellipse(5, -153, 4, 4)
    p.fill(180, 25, 40)
    p.triangle(20, -248, 34, -253, 32, -241)
    p.fill(0, 106, 68)
    p.rect(-29, -249, 10, 6)
    p.fill(220, 20, 45)
    p.circle(-24, -246, 3.4)
    p.noFill()
    p.stroke(15)
    p.line(-38, -170, -18, -170)
    p.line(18, -170, 38, -170)
    // Neck and white collar.
    p.noStroke()
    fill(p, [204, 151, 121])
    p.rect(-9, -282, 18, 24, 5)
    p.fill(250)
    p.triangle(-14, -276, 0, -263, -3, -284)
    p.triangle(14, -276, 0, -263, 3, -284)
  },
  head(p, P) {
    const e = P.expr
    p.push()
    p.translate(0, -299)
    p.noStroke()
    fill(p, [205, 153, 124])
    p.ellipse(-22, -5, 10, 16)
    p.ellipse(22, -5, 10, 16)
    fill(p, [220, 171, 140])
    p.ellipse(0, 0, 44, 57)
    p.fill(200, 150, 120, 120)
    p.ellipse(0, 20, 30, 12)
    // Hair.
    p.fill(48, 48, 49)
    p.arc(0, -10, 47, 38, Math.PI, Math.PI * 2, p.CHORD)
    p.ellipse(-2, -22, 40, 16)
    p.fill(60)
    p.rect(-22, -12, 5, 20, 3)
    p.rect(17, -12, 5, 20, 3)
    p.fill(80, 80, 82)
    p.arc(4, -24, 26, 10, Math.PI, Math.PI * 2)
    // Cheeks.
    p.fill(226, 140, 120, e.blush ? 130 : 50)
    p.ellipse(-12, 9, 8, 5)
    p.ellipse(12, 9, 8, 5)
    eyesFront(p, 0, -2, 9, e, {
      brow: [55, 42, 38],
      iris: [35, 30, 28],
      glasses: [38, 40, 45],
      lensW: 16,
      lensH: 12,
      browY: 9,
    })
    p.stroke(167, 111, 90)
    p.strokeWeight(1.5)
    p.line(0, 0, -2, 10)
    p.line(-2, 10, 2, 11)
    mouthFront(p, 0, 19, e, [130, 65, 65], 12)
    p.pop()
  },
}

/* ------------------------------------------------------------------ */
/*  3 · Salauddin Ahmed — navy suit, open collar, rectangular glasses  */
/* ------------------------------------------------------------------ */

const S_SKIN: RGB = [224, 164, 126]
const S_SUIT: RGB = [27, 39, 68]
const S_TROUSER: RGB = [22, 27, 39]

const salauddin: Spec = {
  hip: -90,
  thigh: 46,
  shin: 44,
  foot: -6,
  stance: 12,
  shoulderX: 36,
  shoulderY: -226,
  upper: 45,
  fore: 41,
  neck: { x: 0, y: -240 },
  leg(p, l, back) {
    const c = back ? darker(S_TROUSER, 0.75) : S_TROUSER
    limb(p, l.hip, l.knee, 20, c)
    limb(p, l.knee, l.ankle, 17, c)
    p.stroke(45, 52, 70)
    p.strokeWeight(1)
    p.line(l.hip.x + 3, l.hip.y, l.knee.x + 3, l.knee.y)
  },
  shoe(p, a, ang, back) {
    p.push()
    p.translate(a.x, a.y)
    p.rotate(ang)
    p.noStroke()
    p.fill(back ? 6 : 12, back ? 8 : 15, back ? 12 : 22)
    p.ellipse(7, 2, 33, 12)
    p.fill(60, 64, 72, 150)
    p.ellipse(13, -2, 10, 3)
    p.pop()
  },
  arm(p, a, back, P) {
    const c = back ? darker(S_SUIT, 0.78) : S_SUIT
    limb(p, a.sh, a.el, 20, c)
    limb(p, a.el, a.hand, 18, c)
    const cuff = mixV(a.el, a.hand, 0.9)
    p.stroke(245)
    p.strokeWeight(7)
    p.point(cuff.x, cuff.y)
    fist(p, a.hand, back ? darker(S_SKIN, 0.9) : S_SKIN, 17, P.release > 0.3 ? 0 : -0.15)
  },
  torso(p) {
    p.noStroke()
    fill(p, S_TROUSER)
    p.rect(-27, -142, 54, 56, 8)
    p.fill(245, 245, 240)
    p.quad(-28, -236, 28, -236, 27, -139, -27, -139)
    fill(p, S_SUIT)
    p.beginShape()
    p.vertex(-31, -241)
    p.vertex(-47, -225)
    p.vertex(-40, -145)
    p.vertex(-30, -124)
    p.vertex(30, -124)
    p.vertex(41, -145)
    p.vertex(47, -225)
    p.vertex(30, -241)
    p.vertex(0, -225)
    p.endShape(p.CLOSE)
    p.fill(242, 242, 236)
    p.triangle(-12, -235, 0, -217, -3, -165)
    p.triangle(12, -235, 0, -217, 4, -165)
    p.fill(18, 28, 52)
    p.triangle(-30, -240, -12, -232, -16, -176)
    p.triangle(30, -240, 12, -232, 16, -176)
    p.stroke(13, 23, 44)
    p.strokeWeight(1.5)
    p.line(0, -190, 0, -126)
    p.noStroke()
    p.fill(185, 190, 195)
    p.circle(3, -172, 3.5)
    p.circle(3, -146, 3.5)
    p.noFill()
    p.stroke(13, 23, 44)
    p.line(-38, -156, -20, -156)
    p.line(20, -156, 38, -156)
    // Neck and open collar.
    p.noStroke()
    fill(p, [220, 163, 128])
    p.rect(-9, -255, 18, 24, 5)
    p.fill(250)
    p.triangle(-13, -240, 0, -221, -6, -246)
    p.triangle(13, -240, 0, -221, 6, -246)
  },
  head(p, P) {
    const e = P.expr
    const hy = -275
    p.noStroke()
    fill(p, [226, 174, 139])
    p.ellipse(-28, hy + 2, 9, 15)
    p.ellipse(28, hy + 2, 9, 15)
    p.ellipse(0, hy, 58, 68)
    p.fill(205, 150, 118, 110)
    p.ellipse(0, hy + 26, 38, 12)
    // Short swept salt-and-pepper hair.
    p.fill(48, 49, 50)
    p.arc(0, hy - 14, 60, 46, Math.PI, Math.PI * 2, p.CHORD)
    p.fill(82, 83, 82)
    p.arc(-7, hy - 17, 36, 22, Math.PI, Math.PI * 2, p.CHORD)
    p.stroke(155, 155, 148)
    p.strokeWeight(1)
    p.line(-22, hy - 27, -10, hy - 34)
    p.line(-8, hy - 29, 5, hy - 35)
    p.line(7, hy - 27, 18, hy - 32)
    p.noStroke()
    p.fill(218, 153, 127, e.blush ? 150 : 70)
    p.ellipse(-19, hy + 12, 9, 5)
    p.ellipse(19, hy + 12, 9, 5)
    eyesFront(p, 0, hy - 5, 12, e, {
      brow: [78, 57, 48],
      iris: [55, 43, 37],
      glasses: [65, 72, 78],
      lensW: 20,
      lensH: 15,
      browY: 9,
    })
    p.noStroke()
    p.fill(199, 137, 111)
    p.ellipse(0, hy + 5, 5, 8)
    p.stroke(173, 112, 93, 150)
    p.strokeWeight(1)
    p.line(-18, hy + 2, -16, hy + 8)
    p.line(18, hy + 2, 16, hy + 8)
    p.line(-19, hy + 14, -14, hy + 17)
    p.line(19, hy + 14, 14, hy + 17)
    mouthFront(p, 0, hy + 19, e, [130, 65, 58], 13)
  },
}

const SPECS: Spec[] = [hasina, yunus, tareq, salauddin]

export type CharacterState = { anim: Anim; t: number; clock: number }

/** Draws fighter `id` at the current origin (feet), facing +x, in native units. */
export function drawCharacter(p: p5, id: number, state: CharacterState, opts: DrawOptions = {}) {
  const spec = SPECS[id] ?? SPECS[0]
  const pose = samplePose(state.anim, state.t, opts.reduced ? 0 : state.clock)
  if (opts.reduced) pose.smear = 0
  drawRig(p, spec, pose, opts)
  return pose
}
