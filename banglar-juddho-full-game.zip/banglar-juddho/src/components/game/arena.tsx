import { useEffect, useRef, useState, type RefObject } from 'react'
import type p5 from 'p5'
import { ANIM_LEN, MODEL_HEIGHT, drawCharacter, type Anim } from './characters'

export type ArenaFrame = {
  x: number[]
  action: string[]
  last: number[]
  hp: number[]
  hit: number[]
  result: string
  active: boolean
  energy: number
  cpuEnergy: number
  paused: boolean
  timeScale: number
  /** Whether the current punch/kick is the heavy combo finisher. */
  heavy?: boolean[]
  /** Strength of the latest hit taken: 1 normal, 2 heavy, 3 special. */
  hitPower?: number[]
}

/* ------------------------------------------------------------------ */
/*  Palette — gouache tones matching the cream / forest / vermilion UI */
/* ------------------------------------------------------------------ */
const INK = '#22332b'
const PAPER = '#efe6cf'
/** Paint splatter colour per attacker, matched to each model's outfit. */
const SPLAT = ['#e7894f', '#264f8b', '#ae1828', '#2a3a62']
const AURA = ['#df704d', '#7fc3ff', '#e3c16a', '#9ebd86']

/** Per-fighter animation bookkeeping; the pose itself comes from the character model. */
type Rig = {
  id: number
  x: number
  y: number
  lastAction: number
  actionAge: number
  lastHit: number
  hitAge: number
  koAge: number
  blockAge: number
  walkClock: number
  splats: { x: number; y: number; r: number; c: string; life: number }[]
}

const makeRig = (id: number, x: number): Rig => ({
  id,
  x,
  y: 0,
  lastAction: 0,
  actionAge: 10,
  lastHit: 0,
  hitAge: 10,
  koAge: 0,
  blockAge: 0,
  walkClock: 0,
  splats: [],
})

const lerp = (a: number, b: number, t: number) => a + (b - a) * t
const clamp01 = (v: number) => Math.max(0, Math.min(1, v))

export function Arena({ frame, ids }: { frame: ArenaFrame; ids: number[] }) {
  const host = useRef<HTMLDivElement>(null)
  const live = useRef({ frame, ids })
  useEffect(() => {
    live.current = { frame, ids }
  }, [frame, ids])
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    const el = host.current!
    let instance: p5 | null = null
    let disposed = false

    import('p5')
      .then(({ default: P5 }) => {
        if (disposed) return
        instance = new P5((s: p5) => sketch(s, el, live), el)
      })
      .catch(() => setFailed(true))

    return () => {
      disposed = true
      instance?.remove()
    }
  }, [])

  return (
    <div
      ref={host}
      className="paint-arena"
      aria-label="Hand-painted fighting arena outside Jatiya Sangsad Bhaban"
    >
      {failed && (
        <div className="webgl-error">
          The painted arena could not load. Refresh the page to try again.
        </div>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  p5.js sketch (instance mode)                                       */
/* ------------------------------------------------------------------ */
function sketch(
  s: p5,
  el: HTMLDivElement,
  live: RefObject<{ frame: ArenaFrame; ids: number[] }>,
) {
  let backdrop: p5.Graphics | null = null
  let grain: p5.Graphics | null = null
  let unit = 30 // pixels per world unit
  let groundY = 0
  let elapsed = 0
  let previous = 0
  let rigs: Rig[] = []
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches

  /* ---------- painterly primitives ---------- */

  // A "boil" index changes ~7 times a second so strokes wobble like
  // hand-drawn animation frames instead of jittering every tick.
  const boil = () => (reduced ? 0 : Math.floor(elapsed * 7))
  const wob = (seed: number, amt: number) =>
    (s.noise(seed * 13.37, boil() * 0.71) - 0.5) * 2 * amt

  /** Layered brush stroke: dark ink underlay, then 2 translucent paint passes. */
  function brush(
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    w: number,
    col: string,
    seed = 0,
    outline = true,
  ) {
    const j = unit * 0.035
    if (outline) {
      s.stroke(INK)
      s.strokeWeight(w + unit * 0.09)
      s.line(x1 + wob(seed, j), y1 + wob(seed + 1, j), x2 + wob(seed + 2, j), y2 + wob(seed + 3, j))
    }
    const c = s.color(col)
    for (let p = 0; p < 2; p++) {
      c.setAlpha(p ? 150 : 255)
      s.stroke(c)
      s.strokeWeight(w * (p ? 0.6 : 1))
      const o = p ? -w * 0.12 : 0
      s.line(
        x1 + o + wob(seed + 4 + p, j),
        y1 + o + wob(seed + 6 + p, j),
        x2 + o + wob(seed + 8 + p, j),
        y2 + o + wob(seed + 10 + p, j),
      )
    }
    // Light catching the top of the stroke.
    const hl = s.color('#fff4dc')
    hl.setAlpha(60)
    s.stroke(hl)
    s.strokeWeight(w * 0.22)
    s.line(x1 - w * 0.2, y1 - w * 0.2, x2 - w * 0.2, y2 - w * 0.2)
  }

  /** Wet-edged blob, built from a few offset translucent ellipses. */
  function blob(x: number, y: number, rx: number, ry: number, col: string, seed = 0, outline = true) {
    if (outline) {
      s.noFill()
      s.stroke(INK)
      s.strokeWeight(unit * 0.07)
      s.ellipse(x + wob(seed, 1.5), y + wob(seed + 1, 1.5), rx * 2, ry * 2)
    }
    s.noStroke()
    const c = s.color(col)
    for (let p = 0; p < 3; p++) {
      c.setAlpha(p === 0 ? 255 : 110)
      s.fill(c)
      s.ellipse(
        x + wob(seed + 2 + p, rx * 0.08),
        y + wob(seed + 5 + p, ry * 0.08),
        rx * 2 * (1 - p * 0.08),
        ry * 2 * (1 - p * 0.08),
      )
    }
    const hl = s.color('#fff4dc')
    hl.setAlpha(55)
    s.fill(hl)
    s.ellipse(x - rx * 0.3, y - ry * 0.35, rx * 0.8, ry * 0.6)
  }

  /* ---------- static backdrop painted once per resize ---------- */

  function paintBackdrop() {
    const w = s.width
    const h = s.height
    const g = s.createGraphics(w, h)
    g.pixelDensity(1)
    g.randomSeed(7)
    g.noiseSeed(7)
    const sx = (wx: number) => w / 2 + wx * unit
    const gy = groundY

    // Sky wash: horizontal watery bands.
    g.noStroke()
    for (let y = 0; y < gy; y += 3) {
      const t = y / gy
      const c = g.lerpColor(g.color('#e8dcbc'), g.color('#c6c7ac'), t)
      c.setAlpha(255)
      g.fill(c)
      g.rect(0, y, w, 4)
    }
    for (let i = 0; i < 260; i++) {
      const c = g.color(g.random(['#f3e6c4', '#d9d3b4', '#c9cdb4', '#e7d2a6']))
      c.setAlpha(28)
      g.fill(c)
      g.ellipse(g.random(w), g.random(gy * 0.8), g.random(80, 260), g.random(14, 40))
    }
    // Sun glow.
    for (let r = 6; r > 0; r--) {
      const c = g.color('#f6dd9a')
      c.setAlpha(18)
      g.fill(c)
      g.ellipse(w * 0.2, gy * 0.22, unit * r * 2.4, unit * r * 2.4)
    }

    const stroke = (col: string, a: number, wt: number) => {
      const c = g.color(col)
      c.setAlpha(a)
      g.stroke(c)
      g.strokeWeight(wt)
    }
    /** Fill a rectangle with many short horizontal dabs for a gouache texture. */
    const dabRect = (x: number, y: number, rw: number, rh: number, col: string, density = 1) => {
      g.noStroke()
      const base = g.color(col)
      g.fill(base)
      g.rect(x, y, rw, rh)
      const n = Math.max(6, Math.floor(((rw * rh) / 120) * density))
      for (let i = 0; i < n; i++) {
        const c = g.color(col)
        const shift = g.random(-18, 18)
        c.setRed(g.red(c) + shift)
        c.setGreen(g.green(c) + shift)
        c.setBlue(g.blue(c) + shift * 0.8)
        c.setAlpha(70)
        g.fill(c)
        g.ellipse(x + g.random(rw), y + g.random(rh), g.random(6, 18), g.random(2, 6))
      }
      stroke(INK, 120, 1.6)
      g.noFill()
      g.beginShape()
      g.vertex(x + g.random(-1, 1), y + g.random(-1, 1))
      g.vertex(x + rw + g.random(-1, 1), y + g.random(-1, 1))
      g.vertex(x + rw + g.random(-1, 1), y + rh + g.random(-1, 1))
      g.vertex(x + g.random(-1, 1), y + rh + g.random(-1, 1))
      g.endShape(g.CLOSE)
    }

    // Distant tree line.
    for (let i = 0; i < 70; i++) {
      const x = g.random(-50, w + 50)
      const c = g.color(g.random(['#6f8c6b', '#7b9775', '#64805f']))
      c.setAlpha(120)
      g.noStroke()
      g.fill(c)
      g.ellipse(x, gy - unit * 4.2 + g.random(-10, 10), g.random(unit * 1.5, unit * 3), g.random(unit * 1.2, unit * 2.2))
    }

    // Jatiya Sangsad Bhaban, flattened into painted planes.
    const by = gy - unit * 2.4
    const bScale = unit * 0.78
    const bx = (u: number) => sx(0) + u * bScale
    dabRect(bx(-3.5), by - 8 * bScale, 7 * bScale, 8 * bScale, '#d0ccb3')
    for (const side of [-1, 1]) {
      dabRect(bx(side * 5.3 - 1.7), by - 6 * bScale, 3.4 * bScale, 6 * bScale, '#bcbda5')
      dabRect(bx(side * 8 - 1.5), by - 4.5 * bScale, 3 * bScale, 4.5 * bScale, '#b3b69f')
      for (let i = 0; i < 3; i++)
        dabRect(bx(side * 5.3 + (i - 1) * 0.8 - 0.09), by - 4.8 * bScale, 0.18 * bScale, 4 * bScale, '#8b9582', 0.4)
    }
    // Circular void and triangular cut-out on the main block.
    g.noStroke()
    g.fill('#344e43')
    g.ellipse(bx(0), by - 5 * bScale, 3.3 * bScale, 3.3 * bScale)
    stroke(INK, 140, 2)
    g.noFill()
    g.ellipse(bx(0), by - 5 * bScale, 3.3 * bScale + 2, 3.3 * bScale - 1)
    g.noStroke()
    g.fill('#d5cfb6')
    g.triangle(bx(-1.3), by - 3.65 * bScale, bx(1.3), by - 3.65 * bScale, bx(0), by - 6.05 * bScale)
    // Flags on poles.
    for (const side of [-1, 1]) {
      const px = bx(side * 13)
      stroke('#5d5a48', 255, 2.2)
      g.line(px, by, px, by - 9 * bScale)
      g.noStroke()
      g.fill('#1d5940')
      g.rect(px, by - 8.8 * bScale, 2.6 * bScale, 1.6 * bScale)
      g.fill('#b84b37')
      g.ellipse(px + 1.15 * bScale, by - 8 * bScale, 0.96 * bScale, 0.96 * bScale)
    }

    // Plaza steps.
    for (let i = 3; i >= 0; i--) {
      const sw = (22 - i * 0.8) * unit * 0.82
      dabRect(sx(0) - sw / 2, by + i * unit * 0.22, sw, unit * 0.26, '#b8b49a', 0.5)
    }

    // Courtyard ground: grass band and stone court with loose perspective lines.
    dabRect(0, gy - unit * 1.2, w, h - gy + unit * 1.2, '#7c8a69', 1.2)
    const courtTop = gy - unit * 0.9
    const courtBottom = Math.min(h, gy + unit * 2.2)
    g.noStroke()
    g.fill('#c7bda0')
    g.quad(sx(-11.5), courtTop, sx(11.5), courtTop, sx(14), courtBottom, sx(-14), courtBottom)
    for (let i = 0; i < 900; i++) {
      const t = g.random()
      const y = lerp(courtTop, courtBottom, t)
      const half = lerp(11.5, 14, t) * unit
      const c = g.color(g.random(['#d4c8a8', '#b9ae90', '#cfc3a2']))
      c.setAlpha(90)
      g.fill(c)
      g.ellipse(w / 2 + g.random(-half, half), y, g.random(8, 20), g.random(2, 5))
    }
    stroke('#a49980', 150, 1.2)
    for (let x = -12; x <= 12; x += 2) g.line(sx(x * 0.96), courtTop, sx(x * 1.17), courtBottom)
    for (let r = 1; r < 4; r++) {
      const y = lerp(courtTop, courtBottom, r / 4)
      const half = lerp(11.5, 14, r / 4) * unit
      g.line(w / 2 - half, y, w / 2 + half, y)
    }

    // Painted trees framing the arena.
    for (const side of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const tx = sx(side * (12.6 + i * 1.6))
        const ty = gy - unit * (0.6 + i * 0.35)
        const sc = 1 - i * 0.12
        stroke('#4e3d2c', 255, unit * 0.22 * sc)
        g.line(tx, ty, tx + g.random(-4, 4), ty - unit * 2 * sc)
        for (let k = 0; k < 26; k++) {
          const c = g.color(g.random(['#355e43', '#2f5039', '#46704e', '#5b8058']))
          c.setAlpha(190)
          g.noStroke()
          g.fill(c)
          const a = g.random(g.TWO_PI)
          const r = g.random(unit * 1.4) * sc
          g.ellipse(tx + Math.cos(a) * r, ty - unit * 3 * sc + Math.sin(a) * r * 1.3, unit * g.random(0.8, 1.5) * sc, unit * g.random(0.7, 1.2) * sc)
        }
      }
    }

    // Soft vignette brushed in from the paper edge.
    g.noFill()
    for (let i = 0; i < 40; i++) {
      stroke('#3a4a3a', 6, 30)
      g.rect(-i * 2, -i * 2, w + i * 4, h + i * 4)
    }
    return g
  }

  /** Paper grain overlay — generated once and composited on top of each frame. */
  function paintGrain() {
    const w = s.width
    const h = s.height
    const g = s.createGraphics(w, h)
    g.pixelDensity(1)
    g.randomSeed(3)
    g.noStroke()
    for (let i = 0; i < (w * h) / 90; i++) {
      const c = g.color(g.random() < 0.5 ? '#fff8e6' : '#5a4a32')
      c.setAlpha(g.random(8, 22))
      g.fill(c)
      g.rect(g.random(w), g.random(h), g.random(1, 2.4), g.random(1, 2.4))
    }
    // Long canvas fibres.
    for (let i = 0; i < (w + h) / 6; i++) {
      const c = g.color('#7d6b4c')
      c.setAlpha(10)
      g.stroke(c)
      g.strokeWeight(1)
      const x = g.random(w)
      const y = g.random(h)
      g.line(x, y, x + g.random(-30, 30), y + g.random(-3, 3))
    }
    return g
  }

  /** Frees an offscreen layer; p5 can throw here after a resize, so fall back to detaching it. */
  function dispose(g: p5.Graphics | null) {
    if (!g) return
    try {
      g.remove()
    } catch {
      const elt = (g as unknown as { elt?: HTMLElement }).elt
      elt?.parentNode?.removeChild(elt)
    }
  }

  function layout() {
    const w = el.clientWidth || window.innerWidth
    const h = el.clientHeight || window.innerHeight
    s.resizeCanvas(w, h)
    const portrait = w / h < 1.2
    unit = portrait ? Math.min(w / 22, h / 18) : Math.min(w / 26, h / 13)
    groundY = h * (portrait ? 0.7 : 0.74)
    dispose(backdrop)
    dispose(grain)
    backdrop = paintBackdrop()
    grain = paintGrain()
  }

  /* ---------- fighters ---------- */

  const worldX = (x: number) => (x - 50) * 0.19
  /** On-screen fighter height in world units. */
  const FIGHTER_HEIGHT = 4.5

  /** Character special effect painted at the rival's position. */
  function drawSpecialFx(r: Rig, rivalPx: number, age: number) {
    const U = unit
    const id = r.id
    const sc = reduced ? 1 : 1 + Math.sin(age * 9) * 0.03
    s.push()
    s.translate(rivalPx, groundY)
    s.scale(sc)
    if (id === 0) {
      // Helmet gang rushes in from both sides, then leaves.
      const approach = clamp01((age - 0.25) / 0.4)
      const leave = Math.max(0, (age - 1.2) / 0.5)
      for (let j = 0; j < 4; j++) {
        const side = j % 2 ? 1 : -1
        const mx = side * (0.8 + (reduced ? 0 : (1 - approach + leave) * 5)) * U
        const depth = j < 2 ? 0.25 * U : -0.25 * U
        s.push()
        s.translate(mx, depth)
        s.scale(-side, 1)
        const swing = reduced ? 0 : Math.sin(age * 16 + j) * 0.6
        brush(-0.1 * U, -0.8 * U, -0.1 * U + Math.sin(swing) * 0.4 * U, 0, U * 0.18, '#263e43', j * 7)
        brush(0.1 * U, -0.8 * U, 0.1 * U - Math.sin(swing) * 0.4 * U, 0, U * 0.18, '#263e43', j * 7 + 3)
        blob(0, -1.15 * U, U * 0.26, U * 0.38, j % 2 ? '#365745' : '#b7473e', j * 11)
        const armA = reduced ? 1 : 0.8 + Math.sin(age * 19 + j) * 0.9
        brush(0.1 * U, -1.35 * U, 0.1 * U + Math.sin(armA) * 0.55 * U, -1.35 * U + Math.cos(armA) * 0.55 * U, U * 0.13, '#c99e78', j * 13)
        blob(0, -1.68 * U, U * 0.2, U * 0.2, '#c99e78', j * 17)
        s.stroke(INK)
        s.strokeWeight(U * 0.05)
        s.fill('#253b35')
        s.arc(0, -1.72 * U, U * 0.52, U * 0.48, s.PI, s.TWO_PI, s.CHORD)
        s.fill('#e2c58c')
        s.rect(-0.26 * U, -1.76 * U, 0.52 * U, 0.07 * U)
        s.pop()
      }
    } else if (id === 1) {
      // Spinning Nobel medal — width follows cos() to read as a coin flip.
      const spin = reduced ? 1 : Math.cos(elapsed * 5)
      const w = Math.max(0.08, Math.abs(spin)) * U * 1.7
      s.push()
      s.translate(0, -1.8 * U)
      s.stroke('#8b713d')
      s.strokeWeight(U * 0.12)
      s.line(0, -0.85 * U, -0.3 * U, -1.9 * U)
      s.line(0, -0.85 * U, 0.3 * U, -1.9 * U)
      blob(0, 0, w / 2, U * 0.85, '#dcb35b', 401)
      s.noFill()
      s.stroke('#f6dfa0')
      s.strokeWeight(U * 0.06)
      s.ellipse(0, 0, w * 0.78, U * 1.32)
      if (Math.abs(spin) > 0.4) {
        s.noStroke()
        s.fill('#8b713d')
        s.textAlign(s.CENTER, s.CENTER)
        s.textSize(U * 0.55 * Math.abs(spin))
        s.text('★', 0, 0)
      }
      // Healing sparkle dabs.
      for (let k = 0; k < 8; k++) {
        const a = elapsed * 2 + k
        const c = s.color('#f6dfa0')
        c.setAlpha(140)
        s.fill(c)
        s.noStroke()
        s.ellipse(Math.cos(a) * U * 1.3, Math.sin(a * 1.3) * U * 1.1, U * 0.1, U * 0.1)
      }
      s.pop()
    } else if (id === 2) {
      // Electric pole with crossbars and painted zigzag bolts.
      brush(0, 0, 0, -6.6 * U, U * 0.38, '#786550', 501)
      for (const hgt of [4.8, 5.8]) {
        brush(-1.4 * U, -hgt * U, 1.4 * U, -hgt * U, U * 0.2, '#514b39', 502 + hgt)
        for (const x of [-1.1, 1.1]) blob(x * U, -(hgt + 0.22) * U, U * 0.12, U * 0.18, '#cbd7bf', 510 + x)
      }
      for (const side of [-1, 1]) {
        const pts = [
          [side * 1.1, 6],
          [side * 1.6, 4.8],
          [side * 0.7, 4.9],
          [side * 1.3, 3.3],
          [side * 0.35, 3.5],
          [0, 1.4],
        ]
        for (const [wgt, col, a] of [
          [U * 0.35, '#f2d18b', 70],
          [U * 0.12, '#fff0a8', 255],
        ] as const) {
          const c = s.color(col)
          c.setAlpha(a)
          s.stroke(c)
          s.strokeWeight(wgt)
          s.noFill()
          s.beginShape()
          pts.forEach(([x, y], k) => s.vertex(x * U + wob(520 + k + side, 3), -y * U + wob(530 + k, 3)))
          s.endShape()
        }
      }
    } else {
      // Open book releasing floating Bengali letters.
      s.stroke(INK)
      s.strokeWeight(U * 0.06)
      s.fill('#f5e5b7')
      s.quad(-0.8 * U, -1.2 * U, 0, -1.05 * U, 0, -0.25 * U, -0.8 * U, -0.4 * U)
      s.quad(0.8 * U, -1.2 * U, 0, -1.05 * U, 0, -0.25 * U, 0.8 * U, -0.4 * U)
      s.stroke('#b9ae90')
      s.strokeWeight(U * 0.025)
      for (let k = 0; k < 3; k++) {
        s.line(-0.65 * U, -0.95 * U + k * 0.18 * U, -0.12 * U, -0.85 * U + k * 0.18 * U)
        s.line(0.65 * U, -0.95 * U + k * 0.18 * U, 0.12 * U, -0.85 * U + k * 0.18 * U)
      }
      s.textAlign(s.CENTER, s.CENTER)
      s.textStyle(s.BOLD)
      s.textSize(U * 0.65)
      ;['অ', 'আ', 'ক', 'খ', 'ব'].forEach((letter, k) => {
        const rise = reduced ? 0.6 : clamp01((age - 0.25) / 1.2)
        const lx = (k - 2) * 0.55 * U + wob(600 + k, 3)
        const ly = -(1.4 + Math.sin(k) * 0.5 + rise * 1.4) * U
        s.stroke(INK)
        s.strokeWeight(U * 0.06)
        s.fill('#f6d778')
        s.text(letter, lx, ly)
      })
    }
    s.pop()
  }

  /** Paint splatter at impact; splats fade slowly like drying ink. */
  function spawnSplat(r: Rig, x: number, y: number, col: string) {
    if (reduced) return
    for (let k = 0; k < 7; k++) {
      r.splats.push({
        x: x + s.random(-1, 1) * unit * 0.7,
        y: y + s.random(-1, 1) * unit * 0.6,
        r: s.random(0.08, 0.28) * unit,
        c: col,
        life: 1,
      })
    }
    if (r.splats.length > 60) r.splats.splice(0, r.splats.length - 60)
  }

  /* ---------- p5 lifecycle ---------- */

  s.setup = () => {
    const c = s.createCanvas(el.clientWidth || 300, el.clientHeight || 300)
    c.elt.setAttribute('aria-hidden', 'true')
    s.pixelDensity(Math.min(window.devicePixelRatio || 1, 1.5))
    s.strokeCap(s.ROUND)
    s.strokeJoin(s.ROUND)
    s.textFont('serif')
    previous = s.millis()
    layout()
    const f = live.current.frame
    rigs = live.current.ids.map((id, i) => makeRig(id, worldX(f.x[i])))
  }

  s.windowResized = () => layout()

  s.draw = () => {
    if (el.clientWidth !== s.width || el.clientHeight !== s.height) layout()
    const { frame: f, ids } = live.current
    const now = s.millis()
    const dt = f.paused ? 0 : Math.min((now - previous) / 1000, 0.05) * f.timeScale
    previous = now

    if (rigs.length !== ids.length || rigs.some((r, i) => r.id !== ids[i]))
      rigs = ids.map((id, i) => makeRig(id, worldX(f.x[i])))

    // Hit-stop: a few frames of near-freeze on impact sell the weight of a blow.
    const impact = !reduced && rigs.some((r) => r.lastHit > 0 && r.hitAge < 0.07)
    const adt = impact ? dt * 0.12 : dt
    elapsed += adt

    // Screen shake scales with the power of the latest hit.
    let shake = 0
    if (!reduced && !f.paused) {
      rigs.forEach((r, i) => {
        if (r.lastHit <= 0 || r.hitAge > 0.28) return
        const power = f.hitPower?.[i] ?? 1
        shake = Math.max(shake, (1 - r.hitAge / 0.28) * (power >= 3 ? 0.32 : power >= 2 ? 0.2 : 0.07) * unit)
      })
    }
    s.push()
    if (shake) s.translate(s.random(-shake, shake), s.random(-shake, shake))

    if (backdrop) s.image(backdrop, 0, 0, s.width, s.height)
    else s.background(PAPER)

    const blend = f.paused ? 0 : reduced ? 1 : 1 - Math.exp(-dt * 22)
    const toPx = (wx: number) => s.width / 2 + wx * unit
    const heightPx = unit * FIGHTER_HEIGHT

    // Draw the CPU first so the player sits on top.
    const order = [1, 0]
    const fxQueue: (() => void)[] = []

    for (const i of order) {
      const r = rigs[i]
      if (!r) continue
      const id = r.id
      const action = f.action[i]
      const dir = f.x[i] < f.x[1 - i] ? 1 : -1
      const target = worldX(f.x[i])
      const walking = Math.abs(target - r.x) > 0.03
      r.x = lerp(r.x, target, 1 - Math.exp(-dt * 5))

      if (r.lastAction !== f.last[i]) {
        r.lastAction = f.last[i]
        r.actionAge = 0
      }
      if (r.lastHit !== f.hit[i]) {
        r.lastHit = f.hit[i]
        r.hitAge = 0
        if (f.hit[i] > 0) spawnSplat(r, toPx(r.x), groundY - heightPx * 0.55, SPLAT[ids[1 - i]] ?? '#b44e40')
      }
      if (!f.paused) {
        r.actionAge += adt
        r.hitAge += adt
      }
      const age = r.actionAge
      const special = f.active && !f.result && action === 'special'
      const winner = !!f.result && f.hp[i] > f.hp[1 - i]
      const loser = (!!f.result && f.hp[i] < f.hp[1 - i]) || (f.active && f.hp[i] <= 0)
      const charged = f.active && !f.result && (i === 0 ? f.energy : f.cpuEnergy) >= 100
      const freshHit = f.hit[i] > 0 && r.hitAge <= r.actionAge
      const power = f.hitPower?.[i] ?? 1

      // Pick the model animation from the combat state.
      let anim: Anim = 'idle'
      let t = elapsed
      if (loser) {
        anim = 'ko'
        t = r.koAge
      } else if (winner) {
        anim = 'victory'
      } else if (freshHit && power >= 2 && r.hitAge < ANIM_LEN.knockback.len) {
        anim = 'knockback'
        t = r.hitAge
      } else if (freshHit && r.hitAge < ANIM_LEN.hurt.len) {
        anim = 'hurt'
        t = r.hitAge
      } else if (action === 'punch') {
        anim = f.heavy?.[i] ? 'heavyPunch' : 'lightPunch'
        t = age
      } else if (action === 'kick') {
        anim = f.heavy?.[i] ? 'heavyKick' : 'frontKick'
        t = age
      } else if (special) {
        anim = 'special'
        t = age
      } else if (action === 'burst') {
        anim = 'aim'
        t = age
      } else if (action === 'block') {
        anim = 'block'
        t = r.blockAge
      } else if (action === 'jump') {
        anim = 'jump'
        t = age
      } else if (walking) {
        anim = 'walk'
        t = r.walkClock
      }
      if (!f.paused) {
        r.koAge = anim === 'ko' ? r.koAge + adt : 0
        r.blockAge = anim === 'block' ? r.blockAge + adt : 0
        if (anim === 'walk') r.walkClock += adt
      }

      // Specials launch the caster into the air and dive toward the rival.
      const yTarget = special ? (reduced ? 0.7 : Math.sin(Math.min(1, age / 1.6) * Math.PI) * 2.5) : 0
      r.y = lerp(r.y, yTarget, blend)
      let drawX = r.x
      if (special) {
        const rivalX = worldX(f.x[1 - i]) - dir * 1.4
        const dive = reduced ? 0.3 : Math.sin(Math.min(1, age / 1.6) * Math.PI)
        drawX = lerp(target, rivalX, dive)
      }

      const px = toPx(drawX)
      const lift = r.y * unit * 1.25
      const k = (heightPx / MODEL_HEIGHT[id]) * (id === 0 ? 0.97 : id === 2 ? 1.03 : 1)

      // Ground shadow shrinks as the fighter leaves the floor.
      s.noStroke()
      const sh = s.color('#2b3b2f')
      sh.setAlpha(Math.max(18, 70 - r.y * 22))
      s.fill(sh)
      const sw = anim === 'ko' ? 3.4 : 1.9
      s.ellipse(px - (anim === 'ko' ? dir * unit * 1.4 : 0), groundY + 2, unit * sw * (1 - Math.min(0.5, r.y * 0.15)), unit * 0.36)

      s.push()
      s.translate(px, groundY - lift)
      s.scale(dir * k, k)
      drawCharacter(s, id, { anim, t, clock: elapsed }, { aura: AURA[id], charged, reduced })
      s.pop()

      // Gunfire burst: muzzle flash and tracers from the rifle.
      if (action === 'burst' && f.active && !f.result && age < 0.7) {
        const mx = px + dir * heightPx * 0.42
        const my = groundY - lift - heightPx * 0.6
        const m = reduced ? 0.8 : 0.75 + Math.sin(age * 28) ** 2 * 0.4
        s.noStroke()
        s.fill('#ffe1a0')
        s.triangle(mx, my - unit * 0.2 * m, mx, my + unit * 0.2 * m, mx + dir * unit * 0.6 * m, my)
        s.stroke('#ffe6af')
        s.strokeWeight(unit * 0.05)
        for (let n = 0; n < 3; n++) {
          const tx = mx + dir * (0.3 + (reduced ? n * 0.8 : (age * 15 + n * 0.8) % 4)) * unit
          s.line(tx, my + n * 0.06 * unit, tx + dir * unit * 0.55, my + n * 0.06 * unit)
        }
      }

      // Ground ring for specials.
      if (special && age < 0.8) {
        const sc = reduced ? 2 : 1 + age * 7
        const c = s.color('#f2d18b')
        c.setAlpha((reduced ? 0.45 : Math.max(0, 0.8 - age)) * 255)
        s.noFill()
        s.stroke(c)
        s.strokeWeight(unit * 0.12)
        s.ellipse(toPx(target), groundY, unit * 1.6 * sc, unit * 0.4 * sc)
      }
      // Impact starburst, bigger for heavy blows and specials.
      const recoil = Math.max(0, 1 - r.hitAge / 0.24)
      if (recoil > 0 && r.lastHit > 0 && !reduced) {
        const kk = (0.8 + (1 - recoil) * 1.5) * (power >= 3 ? 1.6 : power >= 2 ? 1.3 : 1)
        s.push()
        s.translate(px, groundY - lift - heightPx * 0.6)
        s.stroke(power >= 2 ? '#fff1c2' : '#ffe6a3')
        s.strokeWeight(unit * (power >= 2 ? 0.1 : 0.07))
        for (let n = 0; n < 10; n++) {
          const a = (n * Math.PI) / 5 + (n % 2) * 0.2
          const len = n % 2 ? 0.45 : 0.65
          s.line(Math.cos(a) * unit * 0.3 * kk, Math.sin(a) * unit * 0.3 * kk, Math.cos(a) * unit * len * kk, Math.sin(a) * unit * len * kk)
        }
        if (power >= 2) {
          s.noFill()
          s.stroke(255, 240, 200, recoil * 200)
          s.strokeWeight(unit * 0.05)
          s.ellipse(0, 0, unit * 1.6 * kk, unit * 1.6 * kk)
        }
        s.pop()
      }
      if (special && age > 0.25 && age < 1.75) {
        const rivalPx = toPx(worldX(f.x[1 - i]))
        fxQueue.push(() => drawSpecialFx(r, rivalPx, age))
      }
    }
    fxQueue.forEach((fn) => fn())

    // Drying paint splats.
    for (const r of rigs) {
      r.splats = r.splats.filter((sp) => (sp.life -= dt * 0.35) > 0)
      s.noStroke()
      for (const sp of r.splats) {
        const c = s.color(sp.c)
        c.setAlpha(sp.life * 200)
        s.fill(c)
        s.ellipse(sp.x, sp.y, sp.r * 2, sp.r * 1.8)
      }
    }

    s.pop()
    if (grain) s.image(grain, 0, 0, s.width, s.height)
  }
}
