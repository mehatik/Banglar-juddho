export type Game = {
  now: number
  round: number
  scores: number[]
  slowUntil: number
  timeScale: number
  hp: number[]
  x: number[]
  energy: number
  cpuEnergy: number
  burstUsed: boolean
  time: number
  active: boolean
  paused: boolean
  result: string
  action: string[]
  line: string[]
  stun: number[]
  last: number[]
  hit: number[]
  /** Whether each side's current punch/kick is a heavy combo finisher. */
  heavy: boolean[]
  /** Position in the light → light → heavy attack chain. */
  chain: number[]
  /** Last attack type, kept after the action itself clears so chains can continue. */
  lastType: string[]
  /** Consecutive hits landed, and when the latest one landed. */
  combo: number[]
  comboAt: number[]
  /** Strength of the latest hit taken: 1 normal, 2 heavy, 3 special. */
  hitPower: number[]
  /** How the round ended: 'KO', 'TIME', or '' while it is running. */
  finish: string
  strikes: { side: number; type: string; at: number; heavy?: boolean }[]
}
export const fresh = (): Game => ({
  now: 10000,
  round: 1,
  scores: [0, 0],
  slowUntil: 0,
  timeScale: 1,
  hp: [100, 100],
  x: [25, 75],
  energy: 100,
  cpuEnergy: 35,
  burstUsed: false,
  time: 60,
  active: false,
  paused: false,
  result: '',
  action: ['', ''],
  line: ['', ''],
  stun: [0, 0],
  last: [0, 0],
  hit: [0, 0],
  heavy: [false, false],
  chain: [0, 0],
  lastType: ['', ''],
  combo: [0, 0],
  comboAt: [0, 0],
  hitPower: [0, 0],
  finish: '',
  strikes: [],
})

/** Presses within this many combat milliseconds continue an attack chain. */
export const COMBO_WINDOW = 700
/** Landed hits within this window keep the on-screen hit counter going. */
export const HIT_COMBO_WINDOW = 1300

/** Every third consecutive punch/kick is a heavy finisher. */
export function chainStep(prevChain: number, sinceLast: number, prevType: string, type: string) {
  const melee = (t: string) => t === 'punch' || t === 'kick'
  if (melee(type) && melee(prevType) && sinceLast < COMBO_WINDOW) {
    const chain = prevChain + 1
    return { chain, heavy: chain % 3 === 2 }
  }
  return { chain: 0, heavy: false }
}

/** Combat timings in milliseconds for an attack. */
export const attackTiming = (type: string, heavy: boolean) => ({
  /** Delay from button press to the hit landing. */
  strike: type === 'special' ? 850 : heavy ? 230 : 150,
  /** How long the action stays on screen. */
  duration: type === 'special' ? 1800 : type === 'burst' ? 700 : type === 'jump' ? 650 : heavy ? 500 : 350,
  /** Minimum time before the player can act again. */
  cooldown: type === 'special' ? 1800 : type === 'burst' ? 700 : heavy ? 560 : 360,
})
export const finishMatch = (g: Game): Game => {
  const scores = g.scores.map((score, i) => score + (g.hp[i] > g.hp[1 - i] ? 1 : g.hp[i] === g.hp[1 - i] ? 0.5 : 0))
  return { ...g, scores, timeScale: 1, slowUntil: 0,
    result: g.round === 1 ? 'ROUND 1 COMPLETE' : scores[0] === scores[1] ? 'MATCH DRAW' : scores[0] > scores[1] ? 'MATCH VICTORY' : 'MATCH DEFEAT',
    finish: g.hp.some((hp) => hp <= 0) ? 'KO' : 'TIME',
    action: ['', ''], line: ['', ''], heavy: [false, false], strikes: [] }
}
