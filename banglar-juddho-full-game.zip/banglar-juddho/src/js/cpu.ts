/** CPU decisions run on the same 50 ms clock as combat. */
export const cpuTuning = (difficulty: string) =>
  difficulty === 'Hard'
    ? { speed: 1.65, reaction: 220, aggression: 0.48, guard: 0.8, charge: 0.44 }
    : difficulty === 'Easy'
      ? { speed: 0.65, reaction: 420, aggression: 0.09, guard: 0.18, charge: 0.22 }
      : { speed: 1.15, reaction: 320, aggression: 0.26, guard: 0.52, charge: 0.34 }

export function chooseCpuAction(
  difficulty: string,
  distance: number,
  playerAction: string,
  playerAge: number,
  energy: number,
  id: number,
  roll = Math.random(),
): string | null {
  const tuning = cpuTuning(difficulty)
  // React to an exposed wind-up, rather than reading future player inputs.
  if (distance < 18 && playerAge >= 50 && playerAge < 180 &&
      ['punch', 'kick', 'special'].includes(playerAction) && roll < tuning.guard)
    return 'block'
  if (roll > tuning.aggression) return null
  if (energy >= 100 && distance < 32 && playerAction !== 'block') return 'special'
  if (distance >= 16) return null
  // Kicks catch retreating opponents and punish a passive guard.
  if (distance >= 12 || playerAction === 'block' || id === 2) return 'kick'
  return roll < tuning.aggression * 0.65 ? 'punch' : 'kick'
}
