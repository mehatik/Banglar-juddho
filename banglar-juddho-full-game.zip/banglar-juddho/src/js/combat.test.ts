import { describe, expect, it } from 'vitest'
import { fresh, finishMatch, chainStep, attackTiming } from './combat'
import { chooseCpuAction, cpuTuning } from './cpu'

describe('two-round fight', () => {
  it('records round one and clears attacks and slow motion at the break', () => {
    const g = finishMatch({ ...fresh(), hp: [50, 0], slowUntil: 1800, timeScale: 0.35,
      strikes: [{ side: 0, type: 'special', at: 850 }] })
    expect(g.result).toBe('ROUND 1 COMPLETE')
    expect(g.scores).toEqual([1, 0])
    expect(g.strikes).toEqual([])
    expect(g.timeScale).toBe(1)
    expect(g.slowUntil).toBe(0)
  })
  it('uses accumulated round wins instead of final-round health for match results', () => {
    expect(finishMatch({ ...fresh(), round: 2, scores: [1, 0], hp: [0, 90] }).result).toBe('MATCH DRAW')
    expect(finishMatch({ ...fresh(), round: 2, scores: [1, 0], hp: [10, 0] }).result).toBe('MATCH VICTORY')
    expect(finishMatch({ ...fresh(), round: 2, scores: [0, 1], hp: [0, 10] }).result).toBe('MATCH DEFEAT')
  })
  it('awards half a point per fighter for a tied round', () => {
    expect(finishMatch({ ...fresh(), hp: [45, 45] }).scores).toEqual([0.5, 0.5])
  })
  it('starts each round with fresh health and no pending effects', () => {
    const next = { ...fresh(), round: 2, scores: [1, 0] }
    expect(next.hp).toEqual([100, 100])
    expect(next.stun).toEqual([0, 0])
    expect(next.strikes).toEqual([])
  })
  it('makes the second-round CPU faster and more willing to counter', () => {
    expect(cpuTuning('Hard').reaction).toBeLessThan(cpuTuning('Easy').reaction)
    expect(cpuTuning('Hard').speed).toBeGreaterThan(cpuTuning('Easy').speed)
    expect(chooseCpuAction('Easy', 10, 'punch', 100, 0, 1, 0.4)).toBeNull()
    expect(chooseCpuAction('Hard', 10, 'punch', 100, 0, 1, 0.4)).toBe('block')
  })
})

describe('combo chain', () => {
  it('turns every third quick melee press into a heavy finisher', () => {
    const a = chainStep(0, 9999, '', 'punch')
    expect(a).toEqual({ chain: 0, heavy: false })
    const b = chainStep(a.chain, 400, 'punch', 'punch')
    expect(b).toEqual({ chain: 1, heavy: false })
    const c = chainStep(b.chain, 400, 'punch', 'kick')
    expect(c).toEqual({ chain: 2, heavy: true })
    expect(chainStep(c.chain, 400, 'kick', 'punch').heavy).toBe(false)
  })
  it('drops the chain after a pause or a non-melee move', () => {
    expect(chainStep(1, 900, 'punch', 'punch')).toEqual({ chain: 0, heavy: false })
    expect(chainStep(1, 300, 'special', 'punch')).toEqual({ chain: 0, heavy: false })
  })
  it('gives heavy attacks a longer wind-up and recovery', () => {
    expect(attackTiming('punch', true).strike).toBeGreaterThan(attackTiming('punch', false).strike)
    expect(attackTiming('kick', true).cooldown).toBeGreaterThan(attackTiming('kick', false).cooldown)
  })
  it('records whether a round ended by knockout or on time', () => {
    expect(finishMatch({ ...fresh(), hp: [40, 0] }).finish).toBe('KO')
    expect(finishMatch({ ...fresh(), hp: [40, 30], time: 0 }).finish).toBe('TIME')
  })
})
