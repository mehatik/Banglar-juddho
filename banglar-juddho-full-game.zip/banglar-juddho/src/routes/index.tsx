import { useState, useRef, useEffect, useCallback } from 'react'
import {
  Volume2,
  VolumeX,
  Maximize,
  Swords,
  Pause,
  Play,
  HelpCircle,
  ArrowRight,
  Smartphone,
  Settings,
  X,
} from 'lucide-react'
import { Arena } from '../components/game/arena'
import { FighterPreview } from '../components/game/fighter-preview'
import {
  HudEditor,
  HudLayer,
  KoButton,
  SettingsDialog,
  useHudSettings,
  type HudKey,
} from '../components/game/hud'
import { chooseCpuAction, cpuTuning } from '../js/cpu'
import {
  fresh,
  finishMatch,
  chainStep,
  attackTiming,
  COMBO_WINDOW,
  HIT_COMBO_WINDOW,
  type Game,
} from '../js/combat'

const fighters = [
  {
    name: 'Sheikh Hasina',
    audio: '/audio/hasina.mp3',
    style: 'Rooted stance · heavy palm strikes',
    bn: 'শেখ হাসিনা',
    title: 'THE IRON WILL',
    ability: 'Helmet Gang Rush',
    desc: 'Fly into a strike as a helmet gang rushes in, hits your rival, and leaves.',
    line: 'খেলা তো সবে শুরু!',
    color: '#b7473e',
    power: 92,
    speed: 65,
    defense: 80,
  },
  {
    name: 'Dr. Yunus',
    audio: '/audio/yunus.mp3',
    style: 'Compact guard · counter boxing',
    bn: 'ড. ইউনূস',
    title: 'THE QUIET STORM',
    ability: 'Nobel Prize Seal',
    desc: 'A spinning Nobel medal seals the rival and restores health.',
    line: 'ছোট শক্তি, বড় জয়!',
    color: '#477c83',
    power: 72,
    speed: 75,
    defense: 95,
  },
  {
    name: 'Tareq Rahman',
    audio: '/audio/tareq.mp3',
    style: 'Fast footwork · turning kicks',
    bn: 'তারেক রহমান',
    title: 'THE COMEBACK',
    ability: 'Thunder Pole',
    desc: 'Rise into the sky and summon a giant electric pole with thunderbolts.',
    line: 'এবার হবে আসল লড়াই!',
    color: '#ae833a',
    power: 84,
    speed: 95,
    defense: 65,
  },
  {
    name: 'Salauddin Ahmed',
    audio: '/audio/shamsuddin.mp3',
    style: 'Wide stance · powerful hooks',
    bn: 'সালাউদ্দিন আহমেদ',
    title: 'THE WILDCARD',
    ability: 'Book’s Alphabet',
    desc: 'Release Bengali letters from a book to stun your rival.',
    line: 'অক্ষরেই হবে বাজিমাত!',
    color: '#61744a',
    power: 95,
    speed: 70,
    defense: 78,
  },
]
const comboWord = (n: number) =>
  n >= 6 ? 'UNSTOPPABLE!' : n >= 5 ? 'SUPERB!' : n >= 4 ? 'BRUTAL!' : n >= 3 ? 'GREAT!' : 'NICE!'

export default function Home() {
  const [player, setPlayer] = useState(0),
    [cpu, setCpu] = useState(1),
    [target, setTarget] = useState<'player' | 'cpu'>('player')
  const [entered, setEntered] = useState(false)
  const [screenNote, setScreenNote] = useState('')
  const [game, setGame] = useState<Game>(fresh),
    [help, setHelp] = useState(false),
    [muted, setMuted] = useState(false)
  const [hud, setHud] = useHudSettings()
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [editingHud, setEditingHud] = useState(false)
  const hudRef = useRef(hud)
  useEffect(() => {
    hudRef.current = hud
  }, [hud])
  const buzz = useCallback((pattern: number | number[]) => {
    if (hudRef.current.haptics && typeof navigator !== 'undefined') navigator.vibrate?.(pattern)
  }, [])
  const music = useRef<HTMLAudioElement | null>(null)
  const musicFade = useRef<ReturnType<typeof setInterval> | null>(null)
  const [stick, setStick] = useState({ x: 0, y: 0 })
  const voice = useRef<HTMLAudioElement | null>(null)
  const fxPools = useRef<Record<string, HTMLAudioElement[]>>({})
  const lastHitAudio = useRef([0, 0])
  const playFx = useCallback((kind: 'punch' | 'kick' | 'special' | 'effort' | 'pain') => {
    if (mutedRef.current) return
    const pool = (fxPools.current[kind] ||= Array.from({ length: kind === 'pain' ? 2 : 4 }, () => {
      const clip = new Audio(`/audio/fx/${kind}.wav`)
      clip.preload = 'auto'
      clip.volume = kind === 'pain' ? 0.48 : kind === 'effort' ? 0.42 : 0.68
      return clip
    }))
    const clip = pool.find((item) => item.paused || item.ended) || pool[0]
    clip.currentTime = 0
    void clip.play().catch(() => {})
  }, [])
  const [audioNote, setAudioNote] = useState('')
  const state = useRef(game),
    keys = useRef(new Set<string>()),
    arena = useRef<HTMLDivElement>(null),
    audio = useRef<AudioContext | null>(null),
    mutedRef = useRef(muted)
  const combatClock = useRef(10000)
  const lastTick = useRef(0)
  const difficulty = game.round === 1 ? 'Easy' : 'Hard'
  useEffect(() => {
    state.current = game
  }, [game])
  useEffect(() => {
    mutedRef.current = muted
  }, [muted])
  const playVoice = useCallback((id: number) => {
    if (mutedRef.current) return
    voice.current?.pause()
    const clip = new Audio(fighters[id].audio)
    clip.volume = 1.0
    voice.current = clip
    void clip
      .play()
      .catch(() => setAudioNote('Voice unavailable. Toggle sound to retry.'))
  }, [])
  const beginMusic = useCallback(() => {
    const track = (music.current ||= new Audio('/audio/theme.mp3'))
    track.loop = true
    track.muted = mutedRef.current
    if (!track.paused) return
    track.volume = 0
    void track
      .play()
      .then(() => {
        if (musicFade.current) clearInterval(musicFade.current)
        const started = Date.now()
        musicFade.current = setInterval(() => {
          const target = state.current.active ? 0.05 : state.current.result ? 0.15 : 0.3
          track.volume = Math.min(target, ((Date.now() - started) / 2000) * target)
          if (track.volume >= target && musicFade.current) {
            clearInterval(musicFade.current)
            musicFade.current = null
          }
        }, 50)
      })
      .catch(() => setAudioNote('Tap the sound button to enable audio.'))
  }, [])
  useEffect(() => {
    beginMusic()
    const unlock = () => beginMusic()
    window.addEventListener('pointerdown', unlock)
    window.addEventListener('keydown', unlock)
    return () => {
      window.removeEventListener('pointerdown', unlock)
      window.removeEventListener('keydown', unlock)
    }
  }, [beginMusic])
  const sound = useCallback((kind: string = 'punch') => {
    if (mutedRef.current) return
    try {
      audio.current ||= new AudioContext()
      const ctx = audio.current
      void ctx.resume()
      const now = ctx.currentTime
      const duration = kind === 'ko' ? 0.62 : kind === 'special' ? 0.42 : kind === 'kick' ? 0.26 : 0.2

      // A short filtered-noise burst supplies the crunchy, physical impact.
      const length = Math.floor(ctx.sampleRate * duration)
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate)
      const data = buffer.getChannelData(0)
      for (let i = 0; i < length; i++) {
        const decay = Math.pow(1 - i / length, kind === 'ko' ? 1.5 : kind === 'special' ? 2.2 : 3.5)
        data[i] = (Math.random() * 2 - 1) * decay
      }
      const noise = ctx.createBufferSource()
      noise.buffer = buffer
      const filter = ctx.createBiquadFilter()
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(kind === 'kick' ? 850 : 1450, now)
      filter.frequency.exponentialRampToValueAtTime(100, now + duration)
      const noiseGain = ctx.createGain()
      noiseGain.gain.setValueAtTime(kind === 'ko' ? 0.25 : kind === 'special' ? 0.18 : 0.13, now)
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + duration)
      noise.connect(filter)
      filter.connect(noiseGain)
      noiseGain.connect(ctx.destination)
      noise.start(now)
      noise.stop(now + duration)

      // Low body thump plus a quick pitch drop gives each strike weight.
      const osc = ctx.createOscillator()
      const body = ctx.createGain()
      osc.type = 'sine'
      const high = kind === 'ko' ? 95 : kind === 'special' ? 190 : kind === 'kick' ? 125 : 165
      osc.frequency.setValueAtTime(high, now)
      osc.frequency.exponentialRampToValueAtTime(38, now + duration)
      body.gain.setValueAtTime(kind === 'ko' ? 0.3 : kind === 'special' ? 0.22 : 0.16, now)
      body.gain.exponentialRampToValueAtTime(0.001, now + duration)
      osc.connect(body)
      body.connect(ctx.destination)
      osc.start(now)
      osc.stop(now + duration)
    } catch {
      // Sound effects are optional when Web Audio is unavailable.
    }
  }, [])
  const attack = useCallback(
    (side: number, type: string) => {
      const now = combatClock.current
      const locked = (g: Game) =>
        !g.active ||
        g.paused ||
        !!g.result ||
        g.hp.some((hp) => hp <= 0) ||
        now - g.last[side] <
          (side === 1 && !['special', 'burst'].includes(g.action[side])
            ? cpuTuning(difficulty).reaction
            : attackTiming(g.action[side], !!g.action[side] && g.heavy[side]).cooldown) ||
        now < g.stun[side] ||
        (type === 'special' && (side === 0 ? g.energy : g.cpuEnergy) < 100) ||
        (type === 'burst' && (side !== 0 || g.hp[0] > 25 || g.burstUsed))
      const s = state.current
      if (locked(s)) return
      const preview = chainStep(s.chain[side], now - s.last[side], s.lastType[side], type)
      sound(type === 'burst' ? 'kick' : preview.heavy ? 'special' : type)
      if (type === 'punch' || type === 'kick' || type === 'special') playFx(type)
      if (type === 'punch' || type === 'kick') {
        if (preview.heavy || Math.random() < 0.55) playFx('effort')
      }
      if (type === 'special') playVoice(side === 0 ? player : cpu)
      if (side === 0) buzz(type === 'special' ? [20, 40, 60] : preview.heavy ? [16, 24, 22] : 10)
      setGame((prev) => {
        if (locked(prev)) return prev
        const g = {
          ...prev,
          hp: [...prev.hp],
          x: [...prev.x],
          action: [...prev.action],
          line: [...prev.line],
          last: [...prev.last],
          stun: [...prev.stun],
          hit: [...prev.hit],
          heavy: [...prev.heavy],
          chain: [...prev.chain],
          lastType: [...prev.lastType],
        }
        const step = chainStep(prev.chain[side], now - prev.last[side], prev.lastType[side], type)
        g.last[side] = now
        g.action[side] = type
        g.chain[side] = step.chain
        g.heavy[side] = step.heavy
        g.lastType[side] = type
        const id = side === 0 ? player : cpu
        if (type === 'burst') g.burstUsed = true
        if (type === 'special') {
          g.slowUntil = now + 1800
          g.timeScale = 0.35
          g.stun[1 - side] = now + 1800
          g.action[1 - side] = ''
          g.strikes = g.strikes.filter((strike) => strike.side === side)
          g.line[side] = fighters[id].line
          if (side === 0) g.energy = 0
          else g.cpuEnergy = 0
          if (id === 1) g.hp[side] = Math.min(100, g.hp[side] + 15)
        }
        if (type !== 'block')
          g.strikes = [
            ...g.strikes,
            ...(type === 'burst' ? [100, 230, 360] : [attackTiming(type, step.heavy).strike]).map((delay) => ({
              side,
              type,
              at: now + delay,
              heavy: step.heavy,
            })),
          ]
        return g
      })
    },
    [player, cpu, difficulty, sound, playVoice, playFx, buzz],
  )
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (help || !entered || settingsOpen || editingHud) {
        if (e.key === 'Escape') {
          setHelp(false)
          if (!editingHud) setSettingsOpen(false)
        }
        return
      }
      const k = e.key.toLowerCase()
      if (
        [
          'arrowleft',
          'arrowright',
          'arrowup',
          ' ',
          'a',
          'd',
          'w',
          'j',
          'k',
          'l',
          'i',
          's',
          'escape',
        ].includes(k)
      ) {
        e.preventDefault()
        keys.current.add(k)
        if (k === 'j') attack(0, 'punch')
        if (k === 'k') attack(0, 'kick')
        if (k === 'i' && !e.repeat) attack(0, 'burst')
        if (k === 'l' || k === ' ') attack(0, 'special')
        if (k === 'escape' && !e.repeat)
          setGame((g) => (g.active ? { ...g, paused: !g.paused } : g))
      }
    }
    const up = (e: KeyboardEvent) => keys.current.delete(e.key.toLowerCase())
    const blur = () => {
      keys.current.clear()
      setGame((g) => (g.active ? { ...g, paused: true } : g))
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    window.addEventListener('blur', blur)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', blur)
    }
  }, [attack, help, entered, settingsOpen, editingHud])
  useEffect(() => {
    const timer = setInterval(() => {
      const realNow = performance.now()
      const delta = lastTick.current ? Math.min(100, realNow - lastTick.current) : 50
      lastTick.current = realNow
      const s = state.current
      if (!s.active || s.paused || s.result) return
      const scale = combatClock.current < s.slowUntil ? 0.35 : 1
      const step = delta * scale / 50
      combatClock.current += delta * scale
      const now = combatClock.current
      setGame((g) => {
        if (!g.active || g.paused || g.result) return g
        if (g.hp.some((hp) => hp <= 0) || g.time <= 0) return finishMatch(g)
        const next: Game = {
          ...g,
          now,
          timeScale: scale,
          time: Math.max(0, g.time - delta * scale / 1000),
          hp: [...g.hp],
          x: [...g.x],
          stun: [...g.stun],
          hit: [...g.hit],
          last: [...g.last],
          lastType: [...g.lastType],
          combo: [...g.combo],
          comboAt: [...g.comboAt],
          hitPower: [...g.hitPower],
          strikes: g.strikes.filter((strike) => strike.at > now),
        }
        for (const strike of g.strikes.filter((strike) => strike.at <= now)) {
          const { side, type } = strike
          const heavy = !!strike.heavy
          const rival = 1 - side
          const id = side === 0 ? player : cpu
          const opponent = side === 0 ? cpu : player
          const dist = Math.abs(next.x[0] - next.x[1])
          if (now < g.stun[side]) continue
          if (dist >= (type === 'kick' ? 16 : 13) && type !== 'special' && type !== 'burst')
            continue
          const blocked = type !== 'special' && g.action[rival] === 'block'
          const evaded = g.action[rival] === 'jump' && type !== 'special' && type !== 'burst'
          const damage =
            (type === 'special'
              ? [24, 14, 22, 26][id]
              : type === 'burst'
                ? 5
                : type === 'kick'
                ? 10
                : 12) *
            (heavy ? 1.5 : 1) *
            (fighters[id].power / 85) *
            (evaded ? 0 : blocked ? 0.25 : 1) *
            (1 - (fighters[opponent].defense - 65) / 300)
          next.hp[rival] = Math.max(0, next.hp[rival] - damage)
          if (damage > 0) {
            next.hit[rival] = now
            next.hitPower[rival] = blocked ? 1 : type === 'special' || next.hp[rival] === 0 ? 3 : heavy ? 2 : 1
          }
          if (next.hp[rival] === 0) return finishMatch(next)
          if (damage > 0) {
            if (!blocked) {
              const direction = Math.sign(next.x[rival] - next.x[side]) || 1
              next.x[rival] = Math.max(
                7,
                Math.min(
                  93,
                  next.x[rival] + direction * (type === 'kick' ? 3 : 2.6) * (heavy ? 1.8 : 1),
                ),
              )
              next.stun[rival] = Math.max(next.stun[rival], now + (heavy ? 320 : 180))
              next.combo[side] = now - next.comboAt[side] < HIT_COMBO_WINDOW ? next.combo[side] + 1 : 1
              next.comboAt[side] = now
              next.combo[rival] = 0
            }
            if (type !== 'special') {
              if (side === 0) next.energy = Math.min(100, next.energy + 9)
              else next.cpuEnergy = Math.min(100, next.cpuEnergy + 10)
            }
          }
        }
        if (next.hp.some((hp) => hp <= 0)) return finishMatch(next)
        const x = [...next.x]
        const k = keys.current
        const move =
          (k.has('d') || k.has('arrowright') ? 1 : 0) -
          (k.has('a') || k.has('arrowleft') ? 1 : 0)
        x[0] = Math.max(
          7,
          Math.min(
            93,
            x[0] +
              (now < next.stun[0] ||
              ['punch', 'kick', 'special', 'burst', 'block'].includes(g.action[0])
                ? 0
                : move) *
                (0.85 + fighters[player].speed / 100) * step,
          ),
        )
        if (
          now > next.stun[1] &&
          !['punch', 'kick', 'special', 'burst', 'block'].includes(g.action[1]) &&
          Math.abs(x[1] - x[0]) > 11
        )
          x[1] +=
            Math.sign(x[0] - x[1]) *
            cpuTuning(difficulty).speed * (0.75 + fighters[cpu].speed / 200) * step
        // Keep bodies apart instead of letting fighters pass through each other.
        if (Math.abs(x[1] - x[0]) < 7) {
          const center = Math.max(10.5, Math.min(89.5, (x[0] + x[1]) / 2))
          const direction = Math.sign(g.x[1] - g.x[0]) || 1
          x[0] = center - direction * 3.5
          x[1] = center + direction * 3.5
        }
        const action = g.action.map((a, i) =>
          now - g.last[i] > attackTiming(a, g.heavy[i]).duration ? '' : a,
        )
        if (
          now >= g.stun[0] &&
          !['punch', 'kick', 'special', 'burst'].includes(action[0])
        ) {
          if (k.has('s')) action[0] = 'block'
          else if (
            (k.has('w') || k.has('arrowup')) &&
            now - next.last[0] > 850
          ) {
            action[0] = 'jump'
            next.last[0] = now
            next.lastType[0] = 'jump'
          }
        }
        return { ...next, x, action, energy: Math.min(100, next.energy + 0.28 * step),
          cpuEnergy: Math.min(100, next.cpuEnergy + cpuTuning(difficulty).charge * step) }
      })
      const decision = chooseCpuAction(difficulty, Math.abs(s.x[0] - s.x[1]),
        s.action[0], now - s.last[0], s.cpuEnergy, cpu, 1 - (1 - Math.random()) ** step)
      if (decision) attack(1, decision)
    }, 50)
    return () => clearInterval(timer)
  }, [attack, difficulty, player, cpu])
  const resultWinner =
    game.result && game.hp[0] !== game.hp[1]
      ? game.hp[0] > game.hp[1]
        ? player
        : cpu
      : null
  useEffect(() => {
    if (resultWinner !== null) playVoice(resultWinner)
  }, [resultWinner, playVoice])
  useEffect(() => {
    if (music.current) {
      music.current.muted = muted
      if (!musicFade.current) music.current.volume = game.active ? 0.05 : game.result ? 0.15 : 0.3
      if (game.paused) music.current.pause()
      else if (!muted) void music.current.play().catch(() => {})
    }
    if (voice.current) {
      voice.current.muted = muted
      if (game.paused) voice.current.pause()
      else if (!muted && !voice.current.ended) void voice.current.play().catch(() => {})
    }
  }, [muted, game.active, game.paused, game.result, entered])
  useEffect(() => {
    game.hit.forEach((hitAt, index) => {
      if (hitAt && hitAt !== lastHitAudio.current[index]) {
        lastHitAudio.current[index] = hitAt
        playFx('pain')
        if (index === 0) buzz(game.hitPower[0] >= 2 ? [30, 30, 40] : 18)
      }
    })
  }, [game.hit, game.hitPower, playFx, buzz])
  useEffect(
    () => () => {
      if (musicFade.current) clearInterval(musicFade.current)
      music.current?.pause()
      voice.current?.pause()
      Object.values(fxPools.current).flat().forEach((clip) => clip.pause())
      void audio.current?.close()
    },
    [],
  )
  useEffect(() => {
    if (game.result || game.paused) {
      keys.current.clear()
      setStick({ x: 0, y: 0 })
    }
  }, [game.result, game.paused])
  const moveStick = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!state.current.active || state.current.paused || state.current.result)
      return
    const rect = e.currentTarget.getBoundingClientRect()
    const radius = rect.width * 0.32
    const dx = e.clientX - rect.left - rect.width / 2
    const dy = e.clientY - rect.top - rect.height / 2
    const scale = Math.min(1, radius / (Math.hypot(dx, dy) || 1))
    const x = dx * scale,
      y = dy * scale
    setStick({ x, y })
    for (const key of ['a', 'd', 'w', 's']) keys.current.delete(key)
    if (x < -radius * 0.3) keys.current.add('a')
    if (x > radius * 0.3) keys.current.add('d')
    if (y < -radius * 0.45) keys.current.add('w')
    if (y > radius * 0.55) keys.current.add('s')
  }
  const releaseStick = () => {
    setStick({ x: 0, y: 0 })
    for (const key of ['a', 'd', 'w', 's']) keys.current.delete(key)
  }
  const canAct = game.active && !game.paused && !game.result && game.now >= game.stun[0]
  const sinceLast = game.now - game.last[0]
  const cooldown = attackTiming(game.action[0], !!game.action[0] && game.heavy[0]).cooldown
  const recharge = game.action[0] === 'special' || game.action[0] === 'burst' ? 1 : Math.min(1, sinceLast / cooldown)
  // The next melee press lands the heavy finisher: light the buttons up.
  const finisherNext =
    canAct &&
    game.chain[0] % 3 === 1 &&
    ['punch', 'kick'].includes(game.lastType[0]) &&
    sinceLast < COMBO_WINDOW
  const burstReady = game.hp[0] <= 25 && !game.burstUsed
  const controlItems: Record<HudKey, React.ReactNode> = {
    stick: (
      <div
        className="joystick ko-stick"
        role="group"
        aria-label="Movement joystick: left/right to move, up to jump, down to guard"
        onPointerDown={(e) => {
          e.preventDefault()
          e.currentTarget.setPointerCapture(e.pointerId)
          moveStick(e)
        }}
        onPointerMove={(e) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) moveStick(e)
        }}
        onPointerUp={releaseStick}
        onPointerCancel={releaseStick}
        onLostPointerCapture={releaseStick}
      >
        <span className="joystick-directions" aria-hidden="true">
          <i />
          <i />
          <i />
          <i />
        </span>
        <span className="joystick-knob" style={{ transform: `translate(${stick.x}px, ${stick.y}px)` }} />
      </div>
    ),
    punch: (
      <KoButton
        kind="punch"
        tone="red"
        label={finisherNext ? 'HEAVY!' : 'PUNCH'}
        hint="J"
        ring={recharge}
        ready={finisherNext}
        disabled={!canAct}
        ariaLabel="Punch (J)"
        onPress={() => attack(0, 'punch')}
      />
    ),
    kick: (
      <KoButton
        kind="kick"
        tone="amber"
        label={finisherNext ? 'HEAVY!' : 'KICK'}
        hint="K"
        ring={recharge}
        ready={finisherNext}
        disabled={!canAct}
        ariaLabel="Kick (K)"
        onPress={() => attack(0, 'kick')}
      />
    ),
    guard: (
      <KoButton
        kind="guard"
        tone="teal"
        label="GUARD"
        hint="S"
        disabled={!canAct}
        ariaLabel="Hold to guard (S)"
        onPress={() => keys.current.add('s')}
        onRelease={() => keys.current.delete('s')}
      />
    ),
    special: (
      <KoButton
        kind="super"
        tone="gold"
        label={game.energy >= 100 ? 'READY' : `${Math.floor(game.energy)}%`}
        hint="L"
        ring={game.energy / 100}
        ready={game.energy >= 100 && canAct}
        disabled={!canAct || game.energy < 100}
        ariaLabel={game.energy >= 100 ? 'Super power ready (L)' : `Super power charging: ${Math.floor(game.energy)} percent (L)`}
        onPress={() => attack(0, 'special')}
      />
    ),
    burst: (
      <KoButton
        kind="burst"
        tone="ember"
        label={game.burstUsed ? 'USED' : burstReady ? 'BURST' : 'LOCKED'}
        hint="I"
        ring={game.burstUsed ? 0 : Math.min(1, (100 - game.hp[0]) / 75)}
        ready={burstReady && canAct}
        disabled={!canAct || !burstReady}
        title={game.burstUsed ? 'Burst used' : 'Last stand: unlocks at 25% health or less (I)'}
        ariaLabel="Last stand gunfire: press I, single use at 25 percent health or less"
        onPress={() => attack(0, 'burst')}
      />
    ),
  }
  const fullscreen = async () => {
    try {
      if (!document.fullscreenElement) await arena.current?.requestFullscreen()
      const orientation = screen.orientation as ScreenOrientation & {
        lock?: (value: string) => Promise<void>
      }
      await orientation.lock?.('landscape')
    } catch {
      setScreenNote(
        'For the best view, rotate your phone to landscape. Fullscreen depends on your browser.',
      )
    }
  }
  const start = () => {
    keys.current.clear()
    voice.current?.pause()
    beginMusic()
    combatClock.current = 10000
    lastTick.current = 0
    setGame({ ...fresh(), active: true })
    sound('special')
  }
  const select = (id: number) => {
    if (target === 'player') {
      setPlayer(id)
      if (id === cpu) setCpu(player)
    } else {
      setCpu(id)
      if (id === player) setPlayer(cpu)
    }
  }
  return (
    <main className="game-app" ref={arena}>
      <Arena frame={game} ids={[player, cpu]} />
      {audioNote && (
        <button
          className="audio-note"
          onClick={() => {
            setAudioNote('')
            beginMusic()
          }}
        >
          {audioNote}
        </button>
      )}
      <div className="vignette" />
      <header className="game-header">
        <div className="brand">
          <Swords size={21} />
          <span>
            BANGLAR <b>JUDDHO</b>
            <small>বাংলার যুদ্ধ · DHAKA ARENA</small>
          </span>
        </div>
        <div className="toolbar">
          <button
            aria-label="How to play"
            onClick={() => {
              setHelp(true)
              if (game.active) setGame((g) => ({ ...g, paused: true }))
            }}
          >
            <HelpCircle size={19} />
          </button>
          <button
            aria-label={muted ? 'Enable sound' : 'Mute sound'}
            onClick={() => {
              const next = !muted
              mutedRef.current = next
              setMuted(next)
              if (!next) {
                beginMusic()
                setAudioNote('')
              }
            }}
          >
            {muted ? <VolumeX size={19} /> : <Volume2 size={19} />}
          </button>
          <button
            aria-label="Settings and custom HUD"
            onClick={() => {
              setSettingsOpen(true)
              if (game.active) setGame((g) => ({ ...g, paused: true }))
            }}
          >
            <Settings size={19} />
          </button>
          <button aria-label="Fullscreen" onClick={() => void fullscreen()}>
            <Maximize size={19} />
          </button>
          {game.active && (
            <button
              aria-label={game.paused ? 'Resume' : 'Pause'}
              onClick={() => {
                keys.current.clear()
                setGame((g) => ({ ...g, paused: !g.paused }))
              }}
            >
              {game.paused ? <Play size={19} /> : <Pause size={19} />}
            </button>
          )}
        </div>
      </header>
      {game.active && (
        <>
          <section className="hud" aria-label="Match status">
            {[player, cpu].map((id, i) => {
              const power = i ? game.cpuEnergy : game.energy
              return (
                <div className={`health side-${i}${game.hp[i] <= 25 ? ' is-low' : ''}`} key={i}>
                  <div>
                    <strong>{fighters[id].name}</strong>
                    <small>{i ? 'CPU · ' + difficulty : 'YOU · PLAYER 01'}</small>
                  </div>
                  <div className="health-track">
                    <em style={{ transform: `scaleX(${game.hp[i] / 100})` }} />
                    <span style={{ transform: `scaleX(${game.hp[i] / 100})` }} />
                  </div>
                  <div className={`super-track${power >= 100 ? ' is-full' : ''}`} aria-label={`Super power ${Math.floor(power)} percent`}>
                    <i style={{ transform: `scaleX(${power / 100})` }} />
                  </div>
                  <small>
                    {hud.hpNumbers && `${Math.ceil(game.hp[i])} HP · `}
                    {power >= 100 ? (i ? 'POWER READY' : 'SUPER READY · L') : `SUPER ${Math.floor(power)}%`}
                  </small>
                </div>
              )
            })}
            <div className="clock">
              <small>ROUND 0{game.round} / 02 · {difficulty.toUpperCase()}</small>
              <b>{String(Math.ceil(game.time)).padStart(2, '0')}</b>
            </div>
          </section>
          {game.timeScale < 1 && !game.result && <div className="slow-motion-label">SPECIAL · SLOW MOTION <b>35% SPEED</b></div>}
          <div className="arena-caption">
            JATIYA SANGSAD BHABAN <span> DHAKA, BANGLADESH</span>
          </div>
          {game.action.map(
            (action, i) =>
              action === 'special' && (
                <div key={i} className={`power-callout callout-${i}`}>
                  <strong>{fighters[i ? cpu : player].ability}</strong>
                  <span>{game.line[i]}</span>
                </div>
              ),
          )}
          {hud.combo &&
            !game.result &&
            game.combo.map(
              (n, i) =>
                n >= 2 &&
                game.now - game.comboAt[i] < HIT_COMBO_WINDOW && (
                  <div key={`${i}-${n}`} className={`combo-pop combo-${i}`} aria-live="polite">
                    <b>{n}</b>
                    <span>HITS</span>
                    <small>{comboWord(n)}</small>
                  </div>
                ),
            )}
          {game.result && (
            <div className={`ko-splash ${game.finish === 'KO' ? 'is-ko' : 'is-time'}`} aria-live="assertive">
              <b>{game.finish === 'KO' ? 'K.O.' : 'TIME!'}</b>
              <small>{game.hp[0] === game.hp[1] ? 'DRAW' : game.hp[0] > game.hp[1] ? 'YOU WIN' : 'YOU LOSE'}</small>
            </div>
          )}
          {!editingHud && <HudLayer settings={hud} items={controlItems} />}
        </>
      )}
      {!entered && (
        <section className="orientation-intro" aria-label="Rotate your phone">
          <div className="orientation-glow" />
          <div className="orientation-device" aria-hidden="true">
            <svg viewBox="0 0 120 120" role="presentation">
              <g className="orientation-phone-shape"><rect x="42" y="28" width="36" height="64" rx="9" /><path d="M49 37h22M49 83h22" /><circle cx="60" cy="77" r="2" /></g>
            </svg>
          </div>
          <h2>ROTATE YOUR PHONE</h2>
          <p>Banglar Juddho is played in landscape.</p>
          <div className="orientation-rule"><span /></div>
          <small>TURN YOUR DEVICE TO ENTER THE ARENA</small>
        </section>
      )}
      {!entered && (
        <section className="intro-screen overlay">
          <div className="intro-copy">
            <div className="edition">THE BANGLADESH FIGHTING GAME</div>
            <h1>
              BANGLAR
              <br />
              <em>JUDDHO</em>
            </h1>
            <p className="bengali">ময়দান তোমার। লড়াইও তোমার।</p>
            <p>
              Four fighters. Four signature powers.
              <br />
              One showdown at the heart of Dhaka.
            </p>
            <button
              className="primary"
              onClick={() => {
                beginMusic()
                setEntered(true)
                void fullscreen()
                sound('special')
              }}
            >
              ENTER ARENA <ArrowRight size={20} />
            </button>
            <div className="rotate-tip">
              <Smartphone size={20} />
              <span>
                BEST PLAYED IN LANDSCAPE
                <br />
                <small>Rotate your phone · Tap to enter fullscreen</small>
              </span>
            </div>
          </div>
          <div className="intro-stamp">
            <span>বাংলার</span>
            <strong>যুদ্ধ</strong>
            <small>PAINTED ARCADE · BANGLADESH</small>
          </div>
          <div className="disclaimer">
            An original fictional parody game. Abilities and dialogue are
            invented.
          </div>
        </section>
      )}
      {entered && !game.active && (
        <section className="selection overlay">
          <div className="select-heading">
            <span>CHOOSE YOUR SIDE</span>
            <h1>
              PICK YOUR <em>FIGHTER.</em>
            </h1>
            <p>
              {screenNote ||
                'Hand-painted p5.js arcade combat · Jatiya Sangsad Bhaban'}
            </p>
          </div>
          <div className="selection-body">
            <div className="roster">
              <div className="selection-tabs">
                <button
                  className={target === 'player' ? 'selected' : ''}
                  onClick={() => setTarget('player')}
                >
                  01 YOUR FIGHTER
                </button>
                <button
                  className={target === 'cpu' ? 'selected' : ''}
                  onClick={() => setTarget('cpu')}
                >
                  02 OPPONENT
                </button>
              </div>
              <div className="fighter-grid">
                {fighters.map((f, i) => (
                  <button
                    key={f.name}
                    onClick={() => select(i)}
                    className={`fighter-card ${i === player ? 'chosen' : ''} ${i === cpu ? 'rival' : ''}`}
                  >
                    <span className="fighter-number">0{i + 1}</span>
                    <FighterPreview id={i} label={f.name} anim={i === player ? 'victory' : 'idle'} />
                    <strong>{f.name}</strong>
                    <small>
                      {i === player
                        ? 'PLAYER 01'
                        : i === cpu
                          ? 'CPU OPPONENT'
                          : f.title}
                    </small>
                  </button>
                ))}
              </div>
            </div>
            <aside className="fighter-info">
              <span className="edition">
                PLAYER 01 · {fighters[player].title}
              </span>
              <h2>{fighters[player].bn}</h2>
              <h3>{fighters[player].ability}</h3>
              <p>{fighters[player].desc}</p>
              <p className="fighting-style">{fighters[player].style}</p>
              <p className="round-format">TWO ROUNDS<br />01 · EASY — Find your rhythm<br />02 · HARD — Face the counterattack</p>
              <button className="primary" onClick={start}>
                FIGHT NOW <Swords size={19} />
              </button>
              <small>
                {fighters[player].name} vs {fighters[cpu].name}
              </small>
            </aside>
          </div>
          <div className="selection-footer">
            <span>A / D MOVE · W JUMP · S GUARD</span>
            <span>J PUNCH · K KICK · L SPECIAL · 3-HIT HEAVY COMBOS</span>
            <span>TOUCH CONTROLS SUPPORTED</span>
          </div>
        </section>
      )}
      {game.active && game.result && (
        <div
          className="modal-backdrop result-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label="Match newspaper"
        >
          <div className="result-layout">
            <article
              className={`newspaper ${game.hp[0] > game.hp[1] ? 'paper-win' : 'paper-loss'}`}
            >
              <div className="paper-topline">ঢাকা সংস্করণ · ময়দানের খবর</div>
              <h2 lang="bn">
                {game.hp[0] === game.hp[1]
                  ? 'দৈনিক ড্র'
                  : game.hp[0] > game.hp[1]
                    ? 'দৈনিক WWE'
                    : 'দৈনিক জানাজা'}
              </h2>
              <div className="paper-edition">
                BANGLAR JUDDHO · ROUND {game.round} REPORT · FICTIONAL PARODY
              </div>
              <h3 lang="bn">
                {game.hp[0] === game.hp[1]
                  ? 'সমানে সমান! ময়দানে অমীমাংসিত লড়াই'
                  : `${fighters[game.hp[0] > game.hp[1] ? player : cpu].bn} ময়দানের চ্যাম্পিয়ন!`}
              </h3>
              <div className="paper-story">
                <figure>
                  <FighterPreview
                    id={game.hp[0] >= game.hp[1] ? player : cpu}
                    label={fighters[game.hp[0] >= game.hp[1] ? player : cpu].name}
                    anim={game.hp[0] === game.hp[1] ? 'idle' : 'victory'}
                    bust
                  />
                  <figcaption>
                    {fighters[game.hp[0] >= game.hp[1] ? player : cpu].bn}
                  </figcaption>
                </figure>
                <div>
                  <h4>
                    {game.hp[0] === game.hp[1]
                      ? 'HONOURS EVEN IN DHAKA'
                      : game.hp[0] > game.hp[1]
                        ? 'A NEW CHAMPION RISES'
                        : 'A TOUGH DAY AT THE COURTYARD'}
                  </h4>
                  <p lang="bn">
                    {game.hp[0] === game.hp[1]
                      ? 'শেষ ঘণ্টা বেজে গেল। কেউ কাউকে ছাড়েনি! আবার হবে লড়াই।'
                      : game.hp[0] > game.hp[1]
                        ? 'দুর্দান্ত লড়াইয়ে বাজিমাত! সংসদ চত্বরে আজ বিজয়ের উৎসব। প্রতিপক্ষের সামনে এবার নতুন চ্যালেঞ্জ।'
                        : 'শেষ রক্ষা হলো না! জমজমাট লড়াইয়ের পর ময়দানে হার। নতুন কৌশলে আবার ফিরে আসার অপেক্ষা।'}
                  </p>
                  <div className="paper-score">
                    {Math.ceil(game.hp[0])} : {Math.ceil(game.hp[1])}
                    <small>HEALTH REMAINING · {Math.ceil(60 - game.time)}s ELAPSED</small>
                  </div>
                </div>
              </div>
              <span className="paper-stamp">
                {game.hp[0] === game.hp[1]
                  ? 'DRAW'
                  : game.hp[0] > game.hp[1]
                    ? 'ROUND WON'
                    : 'ROUND LOST'}
              </span>
              <footer>কাল্পনিক ব্যঙ্গচিত্র · শুধু খেলার সংবাদ</footer>
            </article>
            <section className="result-actions">
              <span className="edition">EXTRA! EXTRA! · ROUND COMPLETE</span>
              <h2>{game.result}</h2>
              <p>Round {game.round} of 2 · YOU {game.scores[0]} : {game.scores[1]} CPU</p>
              {game.round === 1 && <p>Next: HARD · Faster attacks, stronger defense. Health and power reset.</p>}
              <button autoFocus className="primary" onClick={() => {
                if (game.round === 2) return start()
                keys.current.clear()
                voice.current?.pause()
                lastTick.current = 0
                setGame({ ...fresh(), now: combatClock.current, active: true, round: 2, scores: game.scores })
              }}>
                {game.round === 1 ? 'ROUND 2 · HARD' : 'PLAY AGAIN'} <Swords size={20} />
              </button>
              <button
                className="result-select"
                onClick={() => {
                  keys.current.clear()
                  voice.current?.pause()
                  setGame(fresh())
                }}
              >
                CHARACTER SELECT
              </button>
            </section>
          </div>
        </div>
      )}
      {game.active && game.paused && !game.result && (
        <div className="modal-backdrop">
          <section className="dialog">
            <span className="edition">
              {game.result ? 'ROUND COMPLETE' : 'TAKE A BREATHER'}
            </span>
            <h2>{game.result || 'PAUSED'}</h2>
            <p>
              {game.result
                ? 'The courtyard awaits another showdown.'
                : 'Resume when you are ready.'}
            </p>
            <button
              className="primary"
              onClick={() =>
                game.result
                  ? start()
                  : setGame((g) => ({ ...g, paused: false }))
              }
            >
              {game.result ? 'REMATCH' : 'RESUME'} <Play size={18} />
            </button>
            <button
              className="text-button"
              onClick={() => {
                keys.current.clear()
                setGame(fresh())
              }}
            >
              CHANGE FIGHTERS
            </button>
          </section>
        </div>
      )}
      {help && (
        <div className="modal-backdrop">
          <section className="dialog help-dialog">
            <button
              className="close"
              aria-label="Close instructions"
              onClick={() => setHelp(false)}
            >
              <X />
            </button>
            <span className="edition">LEARN THE CONTROLS</span>
            <h2>OWN THE ARENA.</h2>
            <p>
              A / D or ← / → to move. W / ↑ to jump. Hold S to guard. J punches,
              K kicks, and L or Space unleashes your charged airborne super. Everyone moves at 35% speed during a super, including its caster. Press I for a single-use gunfire burst at 25% HP or less.
              Escape pauses.
            </p>
            <p>
              Chain attacks: two quick punches or kicks set up a third heavy
              finisher that hits harder and knocks your rival back. The punch
              and kick buttons glow “HEAVY!” when it is ready. Land hits in a
              row to build a combo counter.
            </p>
            <p>
              Open Settings (gear icon) to customize the HUD: drag every touch
              control to a new spot, resize it, change opacity, hide buttons,
              or pick a left-handed layout.
            </p>
            <p>
              On mobile, drag the joystick left/right to move, up to jump or
              down to guard. Tap the right buttons to attack. Close the distance
              for punches and kicks. Guard reduces damage; jumping evades
              regular attacks.
            </p>
            <p>
              Specials reach across the arena. Jail traps, the electric pole
              shocks, the Nobel medal heals its caster, and book letters stun.
              Each round lasts 60 combat seconds. Round 1 is Easy; round 2 is Hard. Win rounds to take the match; one each is a draw.
            </p>
            <button className="primary" onClick={() => setHelp(false)}>
              GOT IT
            </button>
          </section>
        </div>
      )}
      {settingsOpen && !editingHud && (
        <SettingsDialog
          hud={hud}
          onChange={setHud}
          onCustomize={() => setEditingHud(true)}
          onClose={() => setSettingsOpen(false)}
        />
      )}
      {editingHud && (
        <HudEditor
          initial={hud}
          onSave={(next) => {
            setHud(next)
            setEditingHud(false)
          }}
          onCancel={() => setEditingHud(false)}
        />
      )}
      <div className="portrait-warning">
        <Smartphone size={36} />
        <strong>ROTATE FOR THE FIGHT</strong>
        <span>Landscape gives you the full arena and controls.</span>
      </div>
    </main>
  )
}
