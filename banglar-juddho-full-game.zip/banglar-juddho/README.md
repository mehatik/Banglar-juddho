# Banglar Juddho — Complete Game

This archive contains the editable game source, character models, artwork, music, sound effects, and configuration.

## Run the game

1. Install Node.js 24.
2. Extract this ZIP and open a terminal in the banglar-juddho folder.
3. Run `npm ci`.
4. Run `npm run dev`.
5. Open http://localhost:3000 in your browser.

The game requires a local web server; opening index.html directly does not run the source application.

## Create a version for hosting

Run `npm run build` and upload the contents of the generated dist folder to your web host, or connect the source to Netlify.

## Controls

A/D or arrow keys: move. W/up: jump. S: guard. J: punch. K: kick. L/space: special. Escape: pause. Touch controls and a customizable HUD are available.

Dependencies are downloaded during installation and are not bundled in this archive.
